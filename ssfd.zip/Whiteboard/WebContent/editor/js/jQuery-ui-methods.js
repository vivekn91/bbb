var jQuery_UI_Methods = {
	wbDatepicker: function () {
		return $(".date-picker").datepicker();
	}
}
