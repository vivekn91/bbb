package com.vr.manager;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.BasicDBList;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import com.mongodb.util.JSON;
import com.vr.dao.MongoDAO;
import java.util.Arrays;

public class MongoDbManager {
	
	/**
	 * 
	 * @param CollectionName
	 * @return boolean
	 */
	public boolean createDbCollection(String CollectionName) {
		boolean isCreated = false;
		try {
			MongoDAO.getDBObj().createCollection(CollectionName);
			isCreated = true;
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
			if ("collection already exists".equals(e.getMessage())) {
				isCreated = true;
			}
		}
		return isCreated;
	}

	/**
	 * 
	 * @param collectionName
	 */
	public String showData(String collectionName) {

		String documentString = null;
		MongoCursor<Document> cursor = null;
		BasicDBList list = new BasicDBList();

		MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);

		cursor = collection.find().iterator();
		try {
			while (cursor.hasNext()) {
				Document doc = cursor.next();
				list.add(doc);
			}
			documentString = JSON.serialize(list);
		} finally {
			cursor.close();
		}
		return documentString;
	}
	
	public long getDocumentCount(String collectionName) {
		long count = 0;
		count = MongoDAO.getDBObj().getCollection(collectionName).count();
		return count;
	}
	
	/**
	 * 
	 * @param collectionName
	 * @param jsondata
	 * @return String
	 */
	public String insertOneDocument(String collectionName, String jsondata) {
		String id = null;
		
		try {
			MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);
			
			Document document = Document.parse(jsondata);

			collection.insertOne(document);
			id = document.getObjectId("_id").toString();
			//System.out.println(id);
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		}
		return id;
	}
	
	/**
	 * 
	 * @param collectionName
	 * @param jsondata
	 * @return boolean
	 */
	
	public boolean insertManyDocument(String collectionName, String jsondata) {
		boolean flag = false;
		try {
			MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);
			List<Document> documents = new ArrayList<Document>();
			for (int i = 0; i < 100; i++) {
				documents.add(Document.parse(jsondata));
			}
			collection.insertMany(documents);
			flag = true;
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		}
		return flag;
	}
	
	/**
	 * 
	 * @param collectionName
	 * @param jsonData
	 * @return string
	 */
	public Document getOneDocument(String collectionName, Document jsonData){
		Document document = new Document();
		try {
			MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);
			
			document = collection.find(jsonData).first();
		
			
		} catch (NullPointerException e) {
			//Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
			document = new Document();
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		}
		//System.out.println(document);
		return document;
	}
	
	/**
	 * 
	 * @param collectionName
	 * @param jsonData
	 * @return string
	 */
	public String getAllDocument(String collectionName, Bson filterBson) {
		String documentString = null;
		MongoCursor<Document> cursor = null;
		BasicDBList list = new BasicDBList();

		try {
			MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);

			cursor = collection.find(filterBson).iterator();

			
			while (cursor.hasNext()) {
				Document doc = cursor.next();
				list.add(doc);
			}
			documentString = JSON.serialize(list);
			//System.out.print(documentString);
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		} finally {
			cursor.close();
		}
		
		//System.out.println(documentString);
		return documentString;
	}
	
	/**
	 * 
	 * @param collectionName
	 * @param jsonData
	 * @param updateJson
	 * @return
	 */
	public boolean updateDocument(String collectionName, Document query,String updateJson){
		boolean flag = false;
		

		// collection.updateOne(Document.parse(jsonData),
		// Document.parse(updateJson));
		try {
			
			MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);
			UpdateResult result = collection.updateMany(query , Document.parse(updateJson));
			Long modifiedDocument = result.getModifiedCount();
			if (modifiedDocument > 0) {
				flag = true;
			}
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		}

		return flag;

	}
	
	/**
	 * 
	 * @param collectionName
	 * @param jsonData
	 * @return
	 */
	public boolean deleteOneDocument(String collectionName, String jsonData) {
		boolean flag = false;
		try {
			MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);
			DeleteResult deleteResult = collection.deleteOne(Document.parse(jsonData));
			Long deletedDocument = deleteResult.getDeletedCount();
			if (deletedDocument > 0) {
				flag = true;
			}
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		}
		return flag;
	}
	
	/**
	 * 
	 * @param collectionName
	 * @param jsonData
	 * @return
	 */
	public boolean deleteManyDocument(String collectionName, String jsonData) {
		boolean flag = false;
		try {
			MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);
			DeleteResult deleteResult = collection.deleteMany(Document.parse(jsonData));
			Long deletedDocument = deleteResult.getDeletedCount();
			if (deletedDocument > 0) {
				flag = true;
			}
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		}
		return flag;
	}
        
        /**
         * 
         * @param collectionName
         * @param filterBson
         * @return 
         */
	
	public Long getDocumentCount(String collectionName, Bson filterBson) {
		Long count = null;
		try {
			MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);
			count= collection.count(filterBson);
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		}
		//System.out.println((count== null)? 0 : count);
		return (count== null)? 0 : count;
	}
        
        /**
         * 
         * @param collectionName
         * @param aggregationQuery
         * @return 
         */
	public String getAggrgationResults(String collectionName, List<Document> aggregationQuery) {
		String documentString = null;
		AggregateIterable<Document> cursor = null;
		BasicDBList list = new BasicDBList();

		try {
			MongoCollection<Document> collection = MongoDAO.getDBObj().getCollection(collectionName);

			cursor = collection.aggregate(aggregationQuery);

			
			for (Document doc : cursor) {
				list.add(doc);
			}
			documentString = JSON.serialize(list);
			//System.out.print(documentString);
		} catch (Exception e) {
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		}
		
		//System.out.println(documentString);
		return documentString;
	}
	
	
	public static void main(String args[]){
		//MongoDbManager dbManager=new MongoDbManager();
		
		//String value ="{'_id': '57e50efd3267420444721ad5'}";
		
		//String collectionName="project";
		
		//String value ="{'restaurant_id': {'$eq':'50018989'}}";
		//String value ="{'restaurant_id': {'$gt':'60018989'}}";
		
		//String value ="{'address.zipcode': {'$eq':'10001'}}";
		//String value ="{'address.zipcode': {'$eq':'10001'},'restaurant_id': {'$eq':'50018989'}}";
		
		//String value ="{ 'userid' : { '$eq' : '526101' } }";
		
		//String value ="{'restaurant_id': {'$eq':'50018989'},'address': {'$eq':'10001'},}";
		
		//String value = "{'email': {'$eq':'526101'},'password': {'$eq':'1234'}}";
		
		//String updateValue = "{'$set':{'address':{'street':'Mother Gaston Blvd', 'zipcode':'11213'}}}";
                //aggregate([{"$group":{_id:"$category",count:{$sum:1}}}])
		
		//dbManager.showData("project");
		
		//dbManager.createDbCollection(collectionName);
		
		//String value = "{comments:[]}";
		
		//String value = "{'_id': '57eb66b3b214c24fc44ea822'}";
		
//		Document id= new Document();
		
//		id.append("_id", new ObjectId("57eb66b3b214c24fc44ea822"));
		
		
		
		
//		Document doc = Document.parse("{'content': 'Lorem iplort sit amet'}");
		
//		doc.append("id", new ObjectId().toHexString());

		
//		Document doc1 = new Document();
//		doc1.append("comments", doc);
//		
//		Document doc2 = new Document();
//		doc2.append("$push", doc1);
		
		
		//dbManager.insertOneDocument("comment", value);
		//dbManager.getAllDocument("user", value);
		
//		dbManager.updateDocument("comment", id, doc2.toJson());
		
		//dbManager.deleteOneDocument("wbcollection", value);
		
		
		
	}
}
