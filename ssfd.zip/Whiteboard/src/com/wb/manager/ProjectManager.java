package com.wb.manager;

import java.util.Date;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import com.mongodb.client.model.Filters;

public class ProjectManager {
	
	private static String collection = "project";
	MongoDbManager dbManager = new MongoDbManager();
	
	public String saveProject(String projectJsonStr){
		Document doc = new Document();
		doc = Document.parse(projectJsonStr);
//		doc.append("html", projectJsonStr);
//		doc.append("type", type);
//		doc.append("name", projectName);
//		doc.append("commentId", commentId);
//		doc.append("preview", preview);
		doc.append("date", new Date());
		String id = dbManager.insertOneDocument(collection, doc.toJson());
		
		//System.out.println(doc.toJson());
		doc.append("objectId", id);
		return doc.toJson();
	}
	
	public boolean updateProject(String projectUpdatedJsonStr){
		boolean flag = false;
		try {
			Document doc = new Document();
			doc = Document.parse(projectUpdatedJsonStr);
			// TODO generate query json & projectUpdatedJsonStr
			Document queryDoc = new Document();
			queryDoc.append("_id", new ObjectId(doc.getString("objectId")));

			//Document doc = new Document();
//			doc.append("html", projectUpdatedJsonStr);
			doc.append("date", new Date());
//			doc.append("preview", preview);

			Document updateJson = new Document();
			updateJson.append("$set", doc);

			flag = dbManager.updateDocument(collection, queryDoc, updateJson.toJson());
			flag = true;
		} catch (Exception e) {

		}
		return flag;
	}
	
	public boolean deleteProject(String projectId){
		boolean flag = false;
		Document doc = new Document();
		doc.append("_id", projectId);
		flag = dbManager.deleteOneDocument(collection, doc.toJson());
		return flag;
	}
	
	public String getProjects(String userName, String userId){
		String projectsJson=null;
		Bson filterData=Filters.eq("username", userName);
		String role =  new UserManager().getUserRole(userId);
		if(role == null){
			//TODO remove after fixing in DB
			projectsJson = dbManager.getAllDocument(collection, filterData);
		} else if("TM".equals(role)){
			projectsJson = dbManager.getAllDocument(collection, filterData);
		} else if("TL".equals(role)){
			projectsJson = this.getProjects();
		}
		//System.out.println(projectsJson);
		return projectsJson;
	}
	
	public String getProjects(){
		String projectsJson=null;

		projectsJson = dbManager.showData(collection);
		return projectsJson;
	}
	
	public Long getProjectCountUserBased(String username){
		Bson filterData = Filters.eq("username",username);
		return dbManager.getDocumentCount(collection,filterData);
	}
	
	
	
}
