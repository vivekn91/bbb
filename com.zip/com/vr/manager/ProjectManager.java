/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vr.manager;

import java.util.Date;
import org.bson.Document;

/**
 *
 * @author 526101
 */
public class ProjectManager {

    private static String collection = "vrproject";
    MongoDbManager dbManager = new MongoDbManager();

    /**
     * @param args the command line arguments
     */
   
    public String getProjectHtml(String projectId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String saveProjectHtml(String htmlNodes) {
        Document doc = new Document();
        doc = Document.parse(htmlNodes);
        doc.append("date", new Date());
        String id = dbManager.insertOneDocument(collection, doc.toJson());

        //System.out.println(doc.toJson());
        doc.append("objectId", id);
        return doc.toJson();
    }
    
    public static void main(String args[]){
        
        ProjectManager manager= new ProjectManager();
        
        manager.saveProjectHtml("");
    }

}
