/* 
 * This file holds the angular js relates stuff
 */
var errorCallback = function(){
	alert("Error Contact admin");
	$rootScope.globalLoading = true;
}

var app = angular.module("wbApp", ['ngRoute']);

app.run(function($rootScope) {
    $rootScope.newProjectBtn = false;
    $rootScope.globalLoading = true;
    $rootScope.hasSessionUser = sessionStorage.hasOwnProperty("username");
    $rootScope.sessionUserName = sessionStorage.getItem("username");
    
});



app.config(function ($routeProvider) {
    $routeProvider
            .when("/", {
                templateUrl: "partials/about.html"
            })
            .when("/log", {
                templateUrl: "partials/projects.html",
                controller : "userprojectsController"
            })
            .when("/comment", {
                templateUrl: "partials/comment.html",
                controller : "commentController"
            })
            .when("/detail", {
                templateUrl: "partials/project_detail.html",
                controller : "detailController"
            })
            .when("/configure", {
                templateUrl: "partials/configure.html",
                controller: "configureController"
            })
            .otherwise({
            	 templateUrl: "partials/notfound.html"
            });
            
});


app.filter('dateFormat', function() {

	  // In the return function, we must pass in a single parameter which will be the data we will work on.
	  // We have the ability to support multiple other parameters that can be passed into the filter optionally
	  return function(input) {

	    var output;
	    
	    var date = new Date(input);
	    
	    //output = date.toDateString();
	    output = date.toLocaleDateString();
	    
	    output +=" "+ date.toLocaleTimeString();

	    return output;

	  }
});

app.filter('titleCase', function() {
  return function(input) {
    input = input || '';
    return input.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
  };
});



app.controller("aboutController", ["$rootScope","$scope","$http", function ($rootScope,$scope,$http) {
	
	

	$scope.getStarted = function(){
		if($rootScope.hasSessionUser){
			$http({
	    		method : "GET",
	    		url : "action",
	    		params : {action : "getProjectCount",username :$rootScope.sessionUserName}
	    	}).then(function(response){
	    		//console.log(response);
	    		if(response.data > 0){
	    			window.location.href="#/log";
	    		}else{
	    			window.location.href="#/detail";
	    		}
	    	},errorCallback);
		}else{
			alert("Kindly login to continue. Use CTS credentials");
		}
	};
	

	$scope.openBlankEditor = function(){
		
    	
		localStorage.removeItem("layoutdata");
		localStorage.removeItem("template");
		localStorage.removeItem("projectId");
		localStorage.removeItem("commentId");

    	//call for project and comment
    	
		var comment = {}, project = {};
		var data = {};
		data.action = "addThread";
		
		project.type = "HTML";
    	project.html = "";
    	project.projectName =  localStorage.getItem("projectName");
    	project.username = sessionStorage.getItem("username");
		
		$http({
    		method : "post",
    		url : "action",
    		params : data
    	}).then(function(response) {
    		//console.log(response);
    		var commentId = response.data;
    		
			project.commentId = commentId["objectId"];
			
			project = JSON.stringify(project);
			
			$http({
        		method : "post",
        		url : "action",
        		params : {project : project, action: "addProject"}
        	}).then(function(responseFromServer) {
        		responseFromServer = responseFromServer.data;
        		localStorage.removeItem("projectName");
        		localStorage.setItem("commentId", JSON.parse(project).commentId);
        		localStorage.setItem("projectId", responseFromServer.objectId);
        		localStorage.setItem("template","");
        		window.location.href="editor/editor.html";
        	}, errorCallback);
    	}, errorCallback);
	
	}
	
	
	
	
	 $scope.starterTemplate = function(templateData){
			//console.log(data);
		 	
			localStorage.removeItem("layoutdata");
			localStorage.removeItem("template");
			localStorage.removeItem("projectId");
			localStorage.removeItem("commentId");
			
			var comment = {}, project = {};
			var data = {};
			data.action = "addThread";
			
			project.type = "HTML";
			project.html = "";
			project.projectName =  localStorage.getItem("projectName");
			project.username = sessionStorage.getItem("username");
			
			$http({
     		method : "post",
     		url : "action",
     		params : data
     	}).then(function(response) {
     		var commentId = response.data;
				project.commentId = commentId["objectId"];
				
				project = JSON.stringify(project);
				$http({
	        		method : "post",
	        		url : "action",
	        		params : {project : project, action: "addProject"}
	        	}).then(function(responseFromServer) {
	        		responseFromServer = responseFromServer.data;
	        		localStorage.removeItem("projectName");
	        		localStorage.setItem("commentId", JSON.parse(project).commentId);
	        		localStorage.setItem("projectId", responseFromServer.objectId);
	        		localStorage.setItem("template",templateData);
	        		window.location.href="editor/editor.html";
	        	}, errorCallback);
     	}, errorCallback);
			
			
		}
	 
	 //SESSION
	
	 
    }]);

app.controller("loginController",["$rootScope","$scope","$http",function($rootScope,$scope,$http){
	$scope.username_enter="";
	$scope.password_enter="";
	
	 $scope.loginUser = function(){
		 $rootScope.globalLoading = false;	
		 if (($scope.username_enter !== "") && ($scope.password_enter !== "")) {
			 var userData ={
						
						username : $scope.username_enter,
						password : $scope.password_enter
					}
			 
			userData = JSON.stringify(userData);

			$http({
					method : "post",
					url : "user",
					data : userData
				}).then(function(response) {
					reaponseData = response.data;
					if(reaponseData === "null" && reaponseData.userName === undefined){
						alert("Enter Valid username and password");
					} else {
						sessionStorage.setItem('username', reaponseData.userName);
						sessionStorage.setItem('userid', reaponseData.userid);
						$rootScope.hasSessionUser = sessionStorage.hasOwnProperty("username");
						$rootScope.sessionUserName = sessionStorage.getItem("username");
						$scope.username_enter="";
						$scope.password_enter="";
					}
			}, errorCallback);
			}
		 $rootScope.globalLoading = true;
		 };
		 
		 $scope.logoutUser = function(){
			 sessionStorage.removeItem("username");
			 sessionStorage.removeItem('userid');
			 $rootScope.hasSessionUser = sessionStorage.hasOwnProperty("username");
		 };
	 
	 
		
	
}]);

app.controller("detailController", ["$rootScope","$scope","$http", function ($scope,$rootScope,$http) {
	
	if(!$rootScope.hasSessionUser){
		window.location.href="#/";
	}
	
	$scope.openBlankCanvas = function(){
		
		localStorage.removeItem("layoutdata");
		localStorage.removeItem("template");
		localStorage.removeItem("projectId");
		localStorage.removeItem("commentId");
		
		var project = {};
		
		project.type = "Canvas";
    	project.html = "";
    	project.projectName =  localStorage.getItem("projectName");
    	project.username = sessionStorage.getItem("username");
		
    	project = JSON.stringify(project);
    	
		$http({
    		method : "post",
    		url : "action",
    		params : {project : project, action: "addProject"}
    	}).then(function(responseFromServer) {
    		responseFromServer = responseFromServer.data;
    		localStorage.removeItem("projectName");
    		localStorage.setItem("projectId", responseFromServer.objectId);
    		localStorage.setItem("template","");
    		window.location.href="canvas/editor.html";
    	}, errorCallback);

	}
	
	$scope.nlform = new NLForm(document.getElementById('nl-form'));
	
	$scope.showNewTemplate = false;
	$scope.stepMsg ="You are near to start"
	
	$scope.startProjectTemplate = function(){
		// console.log("submit ");
		 var fileds = $scope.nlform.fields;
		 
		 var projectType = fileds[0].fld.innerText.trim();
		 var projectName = fileds[1].fld.innerText.trim();
		 
		 
		 //console.log("projectType "+projectType);
		 
		// console.log("projectName "+projectName);
		 
		 localStorage.setItem("projectName",projectName);
		 
		 if(projectName === "enter name"){
			 alert("Enter project name");
		 }else{
			 
			 if(projectType === "New"){
				 $scope.stepMsg = "Select a template "
				 $scope.showNewTemplate = true;
			 }else{
				 //console.log("$scope.openBlankCanvas()");
				 $scope.openBlankCanvas();
			 }
		 }
		 
	 };
	 
	 $scope.backToForm = function(){
		 $scope.stepMsg = "You are near to start";
		 $scope.showNewTemplate = false;
		 
	 };
	 
	
	 $scope.template = [
                        {name:"Basic",url:"partials/template1.html"},
                        {name:"Basic with carousal",url:"partials/template2.html"},
                        {name:"Portfolio",url:"partials/template3.html"},
                        {name:"Business",url:"partials/template5.html"},
                        {name:"Heroic Features",url:"partials/template6.html"},
                        {name:"Blog Post",url:"partials/template4.html"}

     ]
	 
	 
	
}]);

app.controller("configureController", ["$scope","$http", function ($scope,$http) {
	
	

        $scope.framework = [
            {img: "img/bootstrap-logo.png", title: "Bootstrap", category: "framework", isSelected: false},
            {img: "img/materialize_logo.png", title: "Materialize CSS", category: "framework", isSelected: false}
        ];
        $scope.plugins = [
            {img: "img/logo-jquery.png", title: "jQuery", category: "plugin", isSelected: false},
            {img: "img/jqeryui-logo.png", title: "jQueryUI", category: "plugin", isSelected: false},
            {img: "img/d3-logo.png", title: "D3 Chart", category: "plugin", isSelected: false},
//            {img: "img/highchart-logo.png", title: "Highchart", category: "plugin", isSelected: false}
        ];
        
        $scope.template = [
                           {name:"Basic",url:"partials/template1.html"},
                           {name:"Basic with carousal",url:"partials/template2.html"},
                           {name:"Portfolio",url:"partials/template3.html"},
                           {name:"Business",url:"partials/template5.html"},
                           {name:"Heroic Features",url:"partials/template6.html"},
                           {name:"Blog Post",url:"partials/template4.html"}

        ]
	
		$scope.wbTemplatecolors = [1,2,3];

        $scope.toggleSelection = function (isSelected) {
            isSelected = ($scope.isSelected === false) ? true : false;
        };
	
        
		
       
		

    }]);

app.controller("userprojectsController" ,["$rootScope","$scope", "$http", function($rootScope,$scope, $http){
	
	if(!$rootScope.hasSessionUser){
		window.location.href="#/";
	}
	
	//console.log("In userprojects");
	$scope.loading = true; 
	$scope.noproject = false;
	$http({
		method : "GET",
		url : "action",
		params : {action: "getAllProjects",
			username : $rootScope.sessionUserName, 
			userid : sessionStorage.getItem("userid")}
	}).then(function(response) {
		$scope.loading = false;
		$scope.currentProjects = response.data;
		if($scope.currentProjects.length === 0){
			$scope.noproject = true;
		}
	},errorCallback);
	
	$scope.openEditor = function(data){
		localStorage.removeItem("layoutdata");
		localStorage.removeItem("template");
		localStorage.removeItem("projectId");
		localStorage.removeItem("commentId");
		
		localStorage.setItem("template",data.html);
		localStorage.setItem("projectId",data._id.$oid);
		localStorage.setItem("commentId",data.commentId);
		
		window.location.href="editor/editor.html";
	}
	
	$scope.openCanvas = function(data){
		localStorage.removeItem("layoutdata");
		localStorage.removeItem("template");
		localStorage.removeItem("projectId");
		
		localStorage.setItem("template",data.html);
		localStorage.setItem("projectId",data._id.$oid);
		
		window.location.href="canvas/editor.html";
	}
	
	$scope.startProject = function(data){
		//console.log(data);
		localStorage.removeItem("layoutdata");
		
		localStorage.setItem("template",data.html);
		localStorage.setItem("projectId",data.id);
		
		window.location.href="editor/editor.html";
		
	}
}]);

app.controller("commentController", ["$scope","$http", function ($scope,$http) {
	
	$scope.newProjectBtn = true;

	$scope.showComments = function(id){
		var data = {};
    	data.action = "addThread";
       $.ajax({
            type: 'post',
            url: 'action',
            data: data,
            success: function(commentId) {
            	commentId= JSON.parse(commentId);
                commentBox(commentId["objectId"]);
            }
        });
	}
	
	$scope.sendMail = function(){
		
		var datamail = {
                from: "vivek123@test.com",
                to: ["anand@test.com", "anand@test.com"],
                subject : "WB UI Design for Project Name",
  imageStr: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABMoAAAH0CAIAAABD2VYUAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAADahSURBVHhe7d2hr3TJmSfogvsnNBjggs3WcOFYWtLQ0pCm1qDWgNWi0dCBC41W1rAiLRkaGq1kYskGLZVBgwYGBRoMWNBgQW9kvnGjoiLixDmZGXkz8+bz6KeriDfec+7Jm/f7Kl9Vtfubb/7Hn7by7wAAAHCM8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAXtK3P/u2JJcq89N7MF4CAAC8pINzo/ESAACAmTuNlz//X3+eV53JUWK8BAAAeEn3+7eXwzFyPlsmxksAAABazTC5O1smN42X33zzTV5V67Ro1slw2yhHsSjiNMn7s6ZStrFI6nVy7tqpJFFpjmKb5P2oAgAA8MWUkfLIbJksHi+biWtr29ST3Uq9TevYluJw26iLWw2lXjfU62TYAwAA8PWkwfLgbJm8xni5dVrqzaLvT+piWoe87y7sj4rS2dQBAAC+mEeOl7Fo1slw22iOttYhKqcLzqKYxLquFH1bWTTbehHStq40WwAAgK+nDJYHJ8z142WI7ZFio5zWbf0l9a2a07451PWybu7QL2pbzQAAAF9MM1IemTAfMF7Wi95WT73te4anja07NEo9FrUoznsAAAA+x1f7f0ySRqxwcNssinPXSd5f2DMs1k6XneX9RyVvPkQljpJSDMMtAADAQ9xpvJyMkfMJ89bxEgAAgIe437+9vI7xEgAA4CWlubEklyrz03swXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXsJR33zI+0d47Hd/RX5iAACfZtl4+e3Pvs2rTjoqyaWfmhwlw6O4pCRXK/PTg86jxI9y9afyWSUfjOSOD7l6m3yvD00xto2t+pN77GOff5yzB/icx9v6LuenG8sdN1t4q1o85FDuuM2q+wAAsOvW8XJ3ijsy3Q0vj+LwKBkWi+Z06ya7mg+m/efU00fgrqephL4+bLvI/J7NUW1y1Luoea3Jq/t8u9/9cx7vyHdZ9STNfT7hBd7jW3zCYwMAENaMl7GISu3IULd1eapsHSXDYri0f6L/YFpXJh9bm6N7fMDdveeqb3qPhz/ogd+692k/8Lkj32XVk3z+z/8e3/HzXwUAwNu6738cuzvUpYbomXReeudL+yf6D6Z1ZfKxtTm6xwfc3Xuu+qb3ePiDHvite5/2A5878l1WPcnn//zv8R0//1UAALytO46XRya60jNpHh7N+5vTvnJQ/8G0VHY/sx7vvMKRe0566qNYp69F1JO8/5CrZ7k0+hb54Cy2UU9KJZRiEZUk7z+UYiyKOC1y9Sy2UQ9Rn8h9H3K1qyf54Ke26klcVeTqh1w9y6VKPjiLbdQntnrO9zjJ+w+5+mFYiWIsklifD7Oo1/LBWWyjPrHVc77Hj3K1kg8+5OpZswUA4H7uPl7GaBeJelFX+tNieBQ3jORSpT6N5IML9R9MS2X3M+vxziscueekpz5K68k2abZJXZk3p21dabahacirs93tpKE5bba9vmG+7W01nO57+M67nU1laNhTF7fWyfGjyTbpt01laNjTX9tvJw3NEQAA93Pf8bIp1tvmtOmsTY7CsCHuH8mly93ymbU03OPT7ZF7Tnrqo76tqcy3San0R0ldHDbUmobJNq2b01CK/emwP5zuNb1bMmyobd1hq55XP1XXL7qw1vdMKpMbNkf1dnLDZHjPYbExvO3wwlI80hALAADu7bP/49go9lPfsDlMjor+bqVSry91/uD6o1w9a7a90rDb2Th9p0qu/tRWvTbpqY/6tqYy3yal0h8ldXHYkKR6kUtnk21zVJR637B1SbJ7t2RyeRg2HLlzkrZFLl14w1rfM6mkRX8amnq97S+ZnybDYmN+21qpX90AAMByjxwvh4m22rDYqHuuvklv8sF09zPrXT/dHrnnwYfv25pKv+2Vo1jU6uKlDZPt8FZJqfcNW5cku3dLJpeHYcOld95aF1s3rPU9qdLLZz89zaWzybY5SuanybDYmN+2VupXNwAAsNxjxsveZPw7MhnWPRd937n5B9PJaX2U1pPO6xy556ShPurbmsp8Wxse1cW+YX7zyba/VSj1vmHrkmT3bsnk8jBs2L1z01BvL7phre85clWS2urO5qrJUTI/TYbFxvy2tVK/ugEAgOXuOF4mfXFrzJuMf0cmw7pn2H/kJr35B9PJaXN0jw+4u/c8+Hh9W1OZb2vDo7rYN8xvPtn2twql3jdsXZLs3i2ZXB6GDbt3bhrq7UU3rPU9R64KkweYHCXz02RYbMxvWyv1qxsAAFjuU8fLyYx36VFd7BuayuTmc7sfTFND09NXQl8ctl1kfs/J/edtTWXeMG9O27rSnCbNadOwu500NEdJX6md7rV9t6TZ9rYaTvfdvlWzrrdJv20qQ8Oeuri1Tq47SibNSdo2laFhT39tv500NEcAANzPreNlmtz65LOzrXqjP60vLMlnB26723DEkQ+mpw+2P5UPOvm4kg9ukG9UaeqxbdT1vmdYaYpRCbn0IVfPYhv1pF4X58aTWEexKEexjkURp0WunjXbpK80zvf4Ua5+6CuNuKrI1bNc+pCrH3L1XI+vtTgKsY36xFbP+R5ZLv20mOTqh7pYn9brMKwUsY36xFbP+R4/ytVKPviQq2fNFgCA+1n2by9hyId7gt8EAIAvz3jJfRkqCH4TAAC+POMlKzUjhInibflNAAB4Q8ZLVkpTRC1XeT/5N+BDrgIA8KUZLwEAAFjAeAkAAMACxksAAAAWMF4CAACwgPESAACABYyXAAAALGC8BAAAYAHjJQAAAAsYLwEAAFjAeAkAAMACxksAAAAWMF4CAACwgPESAACABYyXAADc6geeSX5X4NMZLwEAuFUea3gO+V2BT2e8BADgVnms4TnkdwU+3a3j5W/+/PMrki8GuMT3P/zbkyc/KMD7yWMNzyG/K/DpjJfAy2hmuSdMflCA95PHGp5Dflfg0xkvgZfRzHJPmPygAO8njzU8h/yusMLf/Ie/qZOrd/D9X77Pq/O6JJdehPES+NG//R//yyS56XGaWe4Jkx8U4P3ksYbnkN8V1vnM8bIZKV9ryDReAj+azJDGyyPJDwrwfvJYM/WH/+cPefXTNcvld2WRMlmV5IO3UV51/9oX/jRihhxOku88Xv7tr//47SnnbV7/8W9/2jMYL3/xH39Rkks3WHKTXc132Xr4ycN8znPW4iEjpRKLhV7lnvRuGS+//dm3kby/g2aWq/OL//0XKU2xZHg06b86+UEB3k8ea/bEVFlmy7ToE0fcIr8rNytjVWOrXoue3c5yOm97oPolDB9y1ZPP/y3lq0yYa8fLNEb+4vf/8t//8Nf/9t0//W+//uPPf/cv/+33Kf/8982EmS/+UE8OV08RS25ykeY7XvFNP+c5Q/OEZX2PZ3iVe9K7erwsU+VLj5e3D5z5QQHeTx5rDpgMkLvj5W/+x28ieb/CwRv23/rIVY+S35Xb1GNVb36aHBy6StvB/s9XP9jwIVNxycPHeFmSqx/6ynNaOV6mefJP//q73/3l7777p7/77s+/+MNfv/vDv/zqN//0d7/9yy/Pk+ePnfniD0smh/omnzOKlO+SFtd9x895zrD1ve7xDK9yT0KaGyfJTdPxshkp7zdhNrNcSRkLt+ZD4yXAveWxZk9Mj1sz5Hy8vMdoV+4zv+HwW696hoPih9MnH/9Ufldu04xM/RA1n6kOTlyl7WD/5zvyYJ/w8KvGy/SokSPbK6wdL//293/99fc//Pq7P3/7m3/61ff/+utf//FvUnH3P46dTD6RvP/oHNbrYvlaKkVfjHVfT4bFIup9Q1OvT6NYKqWhLiZb9aQvxrqv17bqyeTyvhjrvp7UxXJUtnWl3oa+OKzkVbcedtbFWJdtEuu+/p4mc+Orj5dpWzIv9vV6vdXTJz8owPvJY81UPQsN56LJvJTcY5zrZ8X+u2x933s8z1z8fOrkg05+V27QDBj1+BGLMJlDhkepGMn7jTs3bc1RXv10fT9HvssnPMk7jpfxf3j527/8n9//63e//5f/6/sf/vvB8TKZf8ovR03bZL11VJTiRc21uLA/aoplfVHnsF67rrl30eVbzXV9a92oe2JR1FdNFo264dKerf43sTtepq+RKPaec7wcrrcatiopB6+N5AcFeD95rDmgGYrqYSmSD0aaiS5tI2Ubi1DXm6Nac9p3bl3bXBXJ+7Om0jdc4eAPKr8rN6gHjGbYmBzV0lFJqcQi6YuTtuZo2Hk/R77LvZ9k4X8Zmx41cmR7hcX/0z6//cvfp6+//+t3v//nX53+49h//vvzfxz7d/P/ODY0n/hrpd401NutddJsQyle1FxLxUjef2gqZXt1Z39hcl1z76LLt5oP1muTnrrStPXNRdM5tNUzueQdzMfL+WAZHjteNpPefBocFrcqaRsp2/qorOvkBwV4P3ms2dOMRmVbJ462DCe0KDZHTXFy4XBRDC9Mhpds3WerfoUjP6X8rizSDBsHZ4++ra6U9WSRNMX+6yc48o3u+jCv8n91GRb/317+7p/jf8vnV7/547fxP/OTtr/7yy+bf4GZLx6pP+indUmpxCLU2611f1RSKrEI9bZ0Nj0hiv3pZNs0b3Vu1ZO0LimVWIRmG4bFMLk8rUtKJRbh0noclUQlGW5L6mKsa6WtnPZtuz3N9t18gfGySanXPZPisNJfMr82kh8U4P3ksWZPmSEnya3bmnEuUrb9oiQqRVMZ9iTDYlLqdcNkXZJL95TflXXS+FSSS3v6zrpS1pNF0hT7r59g9xulhvs9zGvNlsnif3v50/9PJB//T0oO/MexxXAAODIVbK2T4eXDYjJvrtWdk+b+2vrCWISL6rvNtVQc1pOty+v6sJhcXU+ao2TrqhDF5qjebl1+ac8bmo+XeTX1wPFyOOZFsR4L63VfLKkrw0vKou6skx8U4P3ksWZPM0kOk1unYkgro9qRRa8/GjZv3WH4LZrmYc8nyO/KQ/UTV10p68kiaYr910+QvtH8e93vSV5utkwWj5cHky/+sDsADIvJsCfZahv2XNRcaxqGFyb9tbudR+q7zY1Uv+jyS5u31rEI9bY5Suqr5qexSIbr5tpLe95Q/a8oy7okenaVkfJ+s2XSzHIpwzGvnwPrtmGxpJyWdd1WtnWxTn5QgPeTx5o9kxlychT6KW44vKV13znUHDUX1oY37BdJc4dhzyfI78pDDYeuGNXqo7Juik1b0jTk1afoH6a435O84myZPMt4WZJLZ329b8irqjnWUQzDtlKsT5N6WzqbntAUS1tfL4vSEyadsQjNJSWlEovQbGvlwrqn6W+OSkolFqHe1p2lXjeE0lb31NtQiqVeNzTrklKJRbHb02zf06XzZCNNlZG8v49mlntgjJcAjTzW7JnMkJOjIg1pkbzfruTNWd9TlKNyWq9rTVvSrPvTepv0PfeT3xXWiQmzHiab7VovOlsmTzFeAg93y2z5aZpZ7oExXgI08lizp54hm2GyPuJG+V1htTJk3m+wfHXGS+BlNLPcJyf+y9hIc1SSHxTg/eSx5oAyQzbDZGzrClfL7wp8OuMl8DKaWe4Jkx8U4P3ksYbnkN8V+HS3jpcAn6aZ5Z4w+UEB3k8ea3gO+V2BT2e8BADgVnms4TnkdwU+nfESAIBb5bGG55DfFfh0xksAAG6VxxqeQ35X4NMZLwEAuFUea3gO+V2BT2e8BAAAYAHjJQAAAAsYLwEAAFjAeAkAAMACxksAAAAWMF4CAACwgPESAACABYyXAAAALGC8BAAAYIFvfgAAAICbffPv/9+/i4iIiIiIiNwY46WIiIiIiIgsiPFSREREREREFsR4KSIiIiIiIgtivBQREREREZEFMV6KiIiIiIjIghgvRUREREREZEGMlyIiIiIiIrIgxksRERERERFZEOOliIiIiIiILIjxUkRERERERBbEeCkiIiIiIiILYrwUERERERGRBTFeioiIiIiIyIIYL0VERERERGRBjJf//v0P3//yH3/58//755G0TpWmR0REREREROZ59/HyN3/+TRks63z35++azq18UymVcrowd7qt3C/nX4r2XSuVyVGd0y0+lEo5vUfq+5+/bVaKC3On29aJh280Pcsz+RbxAGFSzJsPpRiLsu1tnZZ6nXx21hz1OdIzyUWX3/i9Svr7rLqziIiIDPPW/6D901//1EyVdf70w5+a/ibpY0r9SaWs6+LC3Om2cr+cfj+6d61UJkfDyuTCtRl+o3t807jnwjvPb3WPl7CV4fdKxbpe1keKsa2Ldfr6+YrBHbYqzWmfaNhtm+Tgt1iY4TNf+l2WP5WIiNwpv/xPv5xsJzneOcnWTYb1vrjkGZ4k1/+DM/0UIk39hVL/N7F90mnT32TrY8edPo68w6ecV/+NahJvWfPGle3wDd1qrjMsLsz8CRcm7r/wu8xvde+X06T/dlsPMKw3xbI90rxVqYt9wzzRf+lVdXavveXmwwyf+dLvsvypRETkTmk+Qx7/SDnpvOUmqRIZ1vtiU3ndXPkPzvpHEOv5D+U5f2TNPNmn6a8z+cxRH6V1UYp1fVJpivH1ayf9njznr8p1KW9c/d6VdV0saYqTnvQ1NEehrpR6qYTY9sX4Wi9K5pW0DsNtnzjqG84XnVxXSUqxTl+P5mRejHVdrNclUUzKthz12zrDo63LL2puMr/JPHHJ8Bulr6E5CnWlfK1T6kUplkQ9GW63Eg1NW7093eKsrpR63ZCUhhBbERF5njSfIY9/pJx03n6Tvp4qw2JTed1c+c/IS38oz/kja4bJPk1/ncnHi3J0/hAyXseiZHjaFMv6q6b8knyZP2D12zcvlvTFVGmKTaU5jZTiufcnzWVbL4brfhuV3XW/7XPwPluVUqxP63Wf5vR0i9FNSurTrXUsmvWw0jfUSaeT/q11yeTaOqW+1bCVur9Zbx2VlGK/uGLdb7eye7e0qNd9sVSGaxERebY0HyCbD5bpa99Q0lTmDbGuK329pO/vi6WSvvb9TXG4jkW9rdvqYlMvxbreVy7K9f+wHD5EFOt1f1oqsX5gmmGyT9NfZ/I5oxxtfUzpr60ru5d/1dS/Hk2xPmpOm8pTZf62br2hfT1V6mLT0GwjpThpPtIT27oyXNfFrUqT3XserMyvrdOc7l5Yiludx+/QrIdJDU1/UYrlaF7pGyKlvtWwlbp/a91vI6XYL46s6+JWZZiL7jws9pX+VEREnifNB8KyrT8r9otm3VSGbfPTJk09tn1zqpRivzhSHDYMM+ycFy/KTf+w3P328wcdXvKZueX/9nLyOWPrk0rzMaXfFqVYGvrt18vWb0tfrxu2Ks+Q+i07va/nbSmWRZPdetNQb9O66E9jWyvF0tBvI3VzrMuiPq1TNzSJo0ZzWrZ9JbZFXS/rPs3p+dIfDeulUp8O17HtK8P1JKWtXpR1qdTbvtI3REp9qyElHRV9pShHsei3566sOS3Fsij1fl0XS06X/bS56CtFORr2NKclTeXc2/aIiMgzpPk0OPzcOC/GOjI52jot6zrDnr55t+14sd+WpHqkbOujSfGi3PqPyeGjxDZStv1RXXxIbvlfjp18yCj1pqHv3+qM7F7+ldL8MpRtXY/fmUhfLJXnyfAdLMWtN3S33jQM67vNdS7tiXVfGWb3bldUhvdM2apHmtNhc10s62GxWZdMmuvtVkpP3dxc2N+nb5j3DBu20neWSnM0rE+KdaXZDq9qctFRf8Ph5ZML6wyLIiLy2DSfBsu2rh8sztuGlf400vTUKfU46tfXFXcrw6vmxYuy4J+R8Y3nzzc8fYbc8v/3Mn3CqD9klHW9GK5Ldk9LsV5/yaTfiialXveUdVPpj54h/VtWv4/9acmwZ+vCS5ubSlNs1rEYrptKva0zrPfFiypp0Z+mDIslzen5Hpvfol4Pi826pCk2/c22WWwVL91GpS42277SnNbpj0qlORrWJ8W60mzrq+p6na16Sn9UKvWirEuOVFKGRREReWyaT4PDT4l9MS2GxWbRrJtKWvSnkWF9cqt6PS+mxbBztzJc9MVmfTxX/jOy/8bDR+kXzfoZ8v0P39f/lWxap0rTs5XTx5MPdbFeF32xVOpi0hdjXepfLMNfiSjOf3NKZXiHh6d/y85vZi7Guig9cVQWRX/ab8+NWX9aKkVfjHVTTKJSMqwU9bbuiQyLKVE/X3RS10Op1MWkL5ZKnb4ezWFSLIv5OpRKqTfbYrdY1rGdn9bbyPmKHzWnKfngrDkq2TqKenNab9O66E/7bVRCrPt60rQNs3UU9fr0dJcPpVJOSyU0axERecKkD4Ql82Kpx6Ip9pXd07oYiaOS5qjeNpVmHSmVUoxFqcQi1vW2ThwNm/tiXbko1/9jsv/G9fbSU3nnDH8Totgcxa9NXewrXyA+v36Z3Omt/AK/IX7JRUTkc/LFPiXeKQt/Sv4BL/KM8eH7y8SE2cevt4iIfFqMl0fywuNlevQmTYO8YZpfiZKmTURePWmwNFuKiMhnxkfKrdzpU7d/zIuIiIiIiMiCGC9FRERERERkQYyXIiIiIiIisiDGSxEREREREVkQ46WIiIiIiIgsiPFSREREREREFsR4KSIiIiIiIgtivBQREREREZEFMV6KiIiIiIjIghgvRUREREREZEGMlyIiIiIiIrIgxksRERERERFZEOOliIiIiIiILIjxUkRERERERBbEeCkiIiIiIiILYrwUERERERGRBTFeDvIP/+UfmorIFfnmrC82i5K+knK6xYfmaJ5L+/tsfdOtuoiIiIi8eXxGbBOz5SdMmJ88xF737Uzat2Q4hpXK5GhY6U9vz+Se6SgcrIuIiIiIXPkZ8Zf/6ZclzdGrx3hZ53Me8h6/S8/wmxkzWDOJle1wQttqvlN277/VcO8HExEREZFXzJWfEevP7s/wOX5hJuNlKka2Ks02Klv1pthsozKsR5p6s21STktDsx0Wy7ZU7pfyW3TLr9Oz/SrGDJa+1sNYWdfFkqY46Ulfw7Betk09iWJdSUqxydbR5BIRERERedtc+Rnxq46X9RzVzFT9iNU3lEq9GK5jW9Z1jvQ319adzVFJc3nfP7xwWLxHvvB4WS+2iiV9MVWaYl3ZWsd2Xm/Ww2w17F4oIiIiIm+YKz8jbo2Xad1v60opNtumUuql+Dmpp6mt9ZFKWTdtw54mu9f2F9aV/jSy1VPWwwu37rY89Ztev/X1Orb11/q0bKNS6vVRXSn1Ulye4SDXL5r09VSpi01D2V5ab9bDbDXsXigiIiIib5grPyPG5/Lm03lZ18Wm0hxtXb7Vf9ekUapPOSptk0qdUiwNzbY/KimVclpvm3pU6jSnkbpeN/f1so1Kvb1fhu94X0yLuqEUm8WR4rBhbZpBLralWBZNdutNw9X1Zj3MVsPuhSIiIiLyhrnyM+Lwo3l8ZI/0xboyX2813Dv9KFUqk6NJJaUp1tvd9da1TX1Y6VP3zPuPdy7M1rtf0p/Gduv0iuLyDOe6Urx0ctu68Op6sx5mq2H3QhERERF5w1z5GXH3I3tTaY6G9XnxE9KPUqWSFs3pkUpTbBp213Wx3qZFf9RU+tQN8/6ms6z7lNN+cWkOvvvD0/m1x4vL089gqVKK/WnJsKcubq1j0Wy36s16mK2G3QtFRERE5A1z5WfE3Y/sTaU5GtbnxXtnay6qB6eSiyp1PYrlqC6WbV2JRb8tnaXYV5o0p2XbV2I7KZaUer+4NAff/eHp/NrjxeXpZ7BUKcVYF6UnjsqiaE6jmDT1frtVj3UolZJ88GG3LiIiIiJy5afD5hN5/ak9Uh/Vlea0VOri1voVc/W49VZpfgf6db2NRdnWp6USi6bYVIbrJ8l8bDPUiYiIiMhzxufU+8Z4KddlMkMaL0VERETkOeNz6n1jvFyY8i8hn/DfN35mjJciIiIi8pzxOVVEREREREQWxHgpIiIiIiIiC2K8FBERERERkQUxXoqIiIiIiMiCGC9FRERERERkQYyXIiIiIiIisiDGSxEREREREVkQ46WIiIiIiIgsiPFSREREREREFsR4KSIiIiIiIgtivBQRERF5ZH4AeFbN31e7MV6KiIiIPDLpA9y//b//9m55z1f9/Hmq9+XVf0lOs9krOz1/9/fVboyXIiIiIo/Mew5a7/mqnz9P9b68+i/JaTx7Zafn7/6+2o3xUkREROSRec9B6z1f9fPnqd6XV/8lOY1nr+z0/N3fV7sxXoqIiIg8Mu85aL3nq37+PNX78uq/JKfx7JWdnr/7+2o3xksRERGRR+Y9B633fNXPn6d6X179l+Q0nr2y0/N3f1/txngpIiIi8si856D1nq/6+fNU78ur/5KcxrNXdnr+7u+r3RgvRURERB6Z9xy03vNVP3+e6n159V+S03j2yk7P3/19tRvjpYiIiMgj856D1nu+6ufPU70vr/5LchrPXtnp+bu/r3ZjvBQRERF5ZN5z0HrPV/38ufF9+dV//lWTpuGirP0lWfJIF+U0nt3sm//6p7z6dKfn7/6+2o3xUkREROSRWfgZunyAvvEzdLn8xvtMsupVl9dbp+nZyj06U/rmeKpIc3RRyuU33meSK96X+qmaB+srF2X5H42yLvUmcRTNR/rnOY1nt0mzZSTv99SdZX388sbp+bu/r3ZjvBQRERF5ZNZ+hh6u+xz8xHz1B+vdLHzVkSse9U6vrr9tXZl/04OPdKcnT7nifYmHmTzS1U+76pckPUDzDMNH6oulMuzfzWk8u0E/K84HxXqejMQ2mV+45fT83d9XuzFeioiIiDwyCwetI5+hIwc/Ll/3qfpIFr7qyBWPeqdX19+2qUy+78FHutOTp1zxvqSH2X2B1z3wkl+S/vGi2FRSJm3D/t2cxrMb9PPhfEpsTvvLL3V6/u7vq90YL0VEREQemYWDVvMhuN6mdf1ZuaTexmlUmkWs6+2NWfiqI/2z9Q8clVKMRV2ZF8u6Pm22USnrYaVpLttYl0q9Lg3NItb19sZc8b7EA9SP0T9PXzmS239J6qfaLTaVlLo4bJjnNJ7doB4p669D/VFTmVy75fT83d9XuzFeioiIiDwyCwet5hNw2U4WdS7tvyULX3WkecIjLyFVhm3DYrPoM+lpKn3n5NqUS/tvyZL3Zf4qjufGh0nfsf9B1cU6TbFvG141z2k8u0E9UtZfh/qjpjK5dsvp+bu/r3ZjvBQRERF5ZBYOWlsfiOOzcqQ5Ktvhad1Wr2/PwlcdaR4vbUtKpZz2lWFbX6xPS1IxUrblaFipO0uao7IdntZt9fr2LHlfho90xXPe+DDNd4zt1mPsPvPWhZOcxrMb1CNl/XWoP2oqk2u3nJ6/+/tqN8ZLERERkUdm4aDVfAIu2/6T8fBz82Qx3N6Sha86svuo80pZz4v1aVM50tNs551929aFzfaWLHlfhs9zxUNe/TDxvS76Ke0+8/zyYU7j2Q3qkbL+OtQfNZXJtVtOz9/9fbUb46WIiIjII7Nw0Nr6NNx/Mh6eThbD7S1Z+Koju486r5T1vFifNpUjPZN1XynryWK4vSWr3pf+ka54yOseJn2j8r3qxfwBhqd1cX75MKfx7Ab1SFl/HeqPmsrk2i2n5+/+vtqN8VJERETkkVk4aMVn6MjWUVMZng4XZb0kC191pH+8eOa63lSao+PFyFalPiqVpqc/airD0+GirJfkivdl6wHq+nUPed3D9N9rWOxTeqK/vuTI5X1O49kN6pGy/rqlnKZFnfroIqfn7/6+2o3xUkREROSRWT5ovUTe81U/f657X3anr6vHs6aym/4bpcrB7z5pu/r586B2lTIZHpwSJ6fzC7ecnr/7+2o3xksRERGRR+Y9B633fNXPn6vfl+WzWcoVD9N8r7S96LsPm295/jyoXaWZKst2Ytiwe9WW0/N3f1/txngpIiIi8si856D1nq/6+XPL+9KPYZdOd02ue5jyHW/87rfnNJ7dJkbKklz9LKfn7/6+2o3xUkREROSRec9B6z1f9fPnxvclJro6TcNFufphlnz323Maz1b4/MEynJ6/+/tqN8ZLERERkUfmPQet93zVz5+nel9e/ZfkNJ69stPzd39f7cZ4KSIiIvLIvOeg9Z6v+vnzVO/Lq/+SnMazV3Z6/u7vq90YL0VEREQemfcctN7zVT9/nup9efVfktN49spOz9/9fbUb46WIiIjII/Oeg9Z7vurnz1O9L6/+S3Iaz17Z6fm7v692Y7wUEREReWTec9B6z1f9/Hmq9+XVf0lO49krOz1/9/fVboyXIiIiIo/Mew5a7/mqnz9P9b68+i/JaTx7Zafn7/6+2o3xUkREROSRec9B6z1f9fPnqd6XV/8lOY1nr+z0/N3fV7sxXoqIiIg8Mu85aL3nq37+PNX78uq/JKfx7JWdnr/7+2o3xksRERGRR+Y9B633fNXPn6d6X179l+Q0nr2y0/N3f1/t5pt0GQAAAGvlQe01xYR8qW/y1QAAAHAD4yUAAAALGC8BAABYwHgJAADAAsZLAAAAFjBeAgAAsIDxEgAAgAWMlwAAACxgvAQAAGAB4yUAAAALGC8BAABYwHgJAADAAsZLAAAAFjBeAgAAsIDxEgAAgAWMlwAAACzweuPlL/7jL1LyBgAAgOewYLyMee/TRj7jJQAAwBNaOV42U9+RyhWW3ORGz/AMAAAAT+XW8bIMWv3EdaRyhSU3udEzPAMAAMBTudd4GduSYWWrWOtPy7qph63TZlsrR/Vp2W4dzeu5BAAA8DZuGi/raape19tS7Ct9MSXqYXjUFCNxlDT1YXLr2dZRU48MjyZFAACA97FgvMybvW3SV2rNaWz7/mFb3qzbTo6SZpv0FQAAgLfy4PEyKnXywag5zNuu2Dapj2KdzLdJVPo6AADAm7h+vKwHqiZ1Q6xDU4ltqQxP86Yyb7ti26Q+inUy34YoDo8AAAC+vMePl3mzsS2VelHWycJtbd7ZbGuTIwAAgC/s1vEybz7UxVhPKvW2JDrD8KheJ7dsk6iU5Oqx+9TFulKKAAAA7+PK8XJrjmrqzTZpKvW2rheloRzV6+SWbYhiczTfJlEpxbItFQAAgLdy0/+0DwAAAATjJQAAAAsYLwEAAFjAeAkAAMACxksAAAAWMF4CAACwgPESAACABYyXAAAALGC8BAAAYIFrxssfAAAA+Lry7Hch//YSAACABYyXAAAALGC8BAAAYAHjJQAAAAsYLwEAAFjAeAkAAMACxksAAAAWMF4CAACwgPESAACABYyXAAAALGC8BAAAYAHjJQAAAAsYLwEAAFjAeAkAAMACxksAAAAWMF4CAACwwPXj5bc/+7Yklx5h/t0f+2xbnvOpDvrmv/6pWfSuO7qrR31fAAB4HzeNl3n10HnpUePlLS//rj+uu948OTKnfdp4efxuxksAALi3NeNlcu+pZsv8+97vqeo7X/pd7vqzuuvNE+MlAAAwtH68jEX5GjmfZKXY1JO+HuummESlr4f+NBb1tj5NSkNdLKJejsq2Sd8ZmmIs6krSF5uGpKnEui7Guq/Euta0JbHum9NgFinbZpEc6QlRqZtDUyltZVufhijWR822FsXmtBTLtm4oi2S4rpuTZgsAAO/mLuNlP6LUp7FI+rai7u+vrS+s12F4mhb1OhbJbkNj2DPsn9wtVfrTpjhs6BeT06Re14Y9adH39/NSqfSLIip9PUnF/sLhYnJa1JWtdUiVUqwXfTGJdXO0tQ3NKQAAvKF7/dvLIoaW4WnTGY70D4vFRZfsNhSpGCnbWCRN/6Qz1JVh21ZDSanEIhkWk2YbjlwY+mGpn6OGPX0x1PX6DiWlEoukPy2atrz66ToMT3cvj0X/NTTrklwCAIA3c9/xsi8OT4uD/cNicdEluw2hb9vqn3eGeX+y2xCuaAsHL0z6YalU+kWRKn0x1PX5HfJqdFpstR284e7lsei/Fk0nAAC8szXj5e56uKg7w6Q/GZ7WDWF4WrcN11sNoW/b6p93hnl/stsQrmgLBy9M+qmpH6i2evp6Uhd37xCG9wlbbQdvuHt5LPqvRdNZ6ysAAPC13TReluTSWb9tesq2LhZxWo7qnmYd27pY9KdNWzTUxVKpi7X+tN7267JNmkpz1CySyTpStrFI+rZ60Yuj+nSrM41JkbJtFsmRnlBXmnWkbGMRmtNaXd9ta06bzr4h2eofdtbF5hQAAL6868fL223NMw/xVA8DAADwcoyXmfESAADgFp89XqYpriSXnoPxEgAA4BaP/LeXAAAAfBnGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwAJfZLz8h//yD3kFAADAIywbL9OA18x4nzbyxbf+tG8HT6v5s/C1/1CUF7v2Za694RW3Wvtynl/8wN/tVQPAV/Xy42V8l/orvKf69/8d/iwcf70X/TRSc9N//Bv1Lu1Prrjkdd3ys72Tt/r5A8ByK8fL8jV8wj+ky7foF/Bu3u2Xv3m9k5d//CdTOutLttZHXNqfXHHJi3rOV/o+P38AuIfPGC/TIhLbJNZ1sWlI+kqjPt1aw1tpfvljm77WKUdl/aKa529eWr9tKrFu1D1lMUx9FJ2hKcairoStSl//wiavtP9RxLouXtqQNJVY18VY95VYAwC7Fo+Xw0VRH22ttxZzB9vgy6v/LDR/Lvo/Vi/9B2fr1RXDlzksFvNLkuNXhVTpTyeLpF5/bVuvdPjTSIutdVnsNvSLyWlSrwGAI9aPl0msm0qkbGORDNfRHInK3ME2eAflj0P956JZl+TSC2oevt42r254VBdDUynbut73RMo2FkVdqdtKSiUWSb3+2rZe6fCnsfUjuqihpFRikQyLSbMFAOY+Y7ycLJLhui4ecWk/fG3xJ2L4hyv5Gn9emldRtpNF0lxVS0dNSj0WyXA97Azz/mLY9uVtvdLhT2PrR3RdQ7iiDQCYu8t4maRt/0/rfpEM13XxiEv74evp/yht/YH6Gn9e+tcb+le91Vkb1qO4dXlZ94ti3l/UR/3pF1a/2PqHEItkXkyuawhXtAEAc58xXiaxLZXmKK+6dSTvpw62wdfW/KmJRSlGylG9fUXlJfSvoq/X2/40abahuWRrXbZJU2mO8mr7wlhE5U3EC29edV/cXR9sjpRtLJK+rV4AAActGy8fyycAAACAxzJeAgAAsMAXGS8BAAB4LOMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFrh8vfwAAAOBLy+PfMcZLAAAAxvL4d4zxEgAAgLE8/h1jvAQAAGAsj3/HGC8BAAAYy+PfMcZLAAAAxvL4d4zxEgAAgLE8/h1jvAQAAGAsj3/HrBwvv/3Zt8PkYwAAAF5KHv+OWTxe5tUHEyYAAMDryuPfMXcfL+PrJ0+Y33zzTV69scf+EHa/u/cIAACeXx7/jvmM8TIW954wn2RcSY8R8r4zObrd2pvfcrfda+/6c3hbwz9oUWzqfbFvyKsn1ryEEMXh85fisGdYDKU47JkU8+bDsLN25LRpGBaLclo3NNtiqw4AvLM8/h1zl/GyfEaJRUmc3snzjCvzJ7nrc669+S132732rj+H97T1By0qzdFWW+hPn1C8oq0X0h+VbV3fWtcOXpi+1p31tugrta2rQl0v63oxvHDrqq3mYR0AeGd5/Dvmvv/2snbwU0uaOkKzTaKSxLouxjrEttTja6kkk3WRSwea875SirE4d/1YKZpKbEMufVxeivG1roRmm8Q26kkUQy59NDTFIuphqxJy6SyXPm7eiJ4k1lFMohhy6UOufsjVjfuTNH/Q6m1ZD/8wzk+fVvO09XZyVJTi8DQcv7DpnG+3HLmqFOvTeWdSXxWJbRgWAQDy+HfMHf/tZUkpxmKimRnOA0WuTNbNIqmL9bpZJHVxax2LZFjs1W31ulkk5/NBw+66UffEIqmLR9axqNXFc+/+Tep1LIrmdHed1OukbJv6i+r/gEy2xzWX1NuyjkX62p/WlZfQPHD/iorhSyvFWKSvfduRC0PTOdymr029Mb9JKMX6dN6ZNFc1/cMiAEAe/455on972c8MR6aLexSTi5obx6/dbUi26rVhz9aF8+bapGF4k2Srntx+hyQVQ96/svQnInJke1xzSb0t6/rOw+ILaZ653m6ti6ahbC+9MK+65n5bKs1RbX5U3yTZWhelWF8Yi6ZSilEBAAh5/Dvmif7tZT8zNJWyrev3KCbz5iSt622t1OuGrWKtFGMRturJ6ZoPpRKLZFhM5s21ScPwJslWPbn9DkkqDuuvqP8DMtke11xSb8t6UqyPXkLzwMOXlvSvK1WONF99YTLZNke1yVHR3KoklyrD07KeLAAAQh7/jvFvLwfFZN5c9JVkfu2wWGuKwwuT4X12i8m8uTZpGN4k2aont98hScVhnaL5g1Zvy3perE+fX/O0w5eW9G33vjA53lmbHBXDniuKaVFSKrEAAAh5/Dvmvv/2MrZh91NLPznUlWYdi+SWYlocWZdFWRd9JSnF+nSrWG9DXWzWsQj1dthTF7fWsUjqddE0lO3Bdb+4eh3qo1jQ6//cRaWul2Ksm0VSr59c86hpG5X5yxlWSrFfFJMLd5tLZ6xj0euvahZJf/nWDYf15lbNNq8AAM7y+HfME/3by+Q8UGRblWS4PrecNMVYJM06tn0x5NJZqZR6VJLY1vLBT/uTsj4fnjTbJCpJ3v/0JmVRnFuyphLrKCZRDLnUNeRV5dx+0myTqIRcOsul6oZNMcQ6ikkUQy6d5VKlrseaIuaEklyt6nl/1hf7hrx6VuUlRHL12Eurk6urL6yTq6POWjmte+pFcxSGxWJYr4vNtVv3AQDeVh7/jnmu8ZKeOQpucfXfPP7KAgBI8vh3zOLxcp7cx2FmS7jR1X/z+CsLACDJ498xK8dLljj/h58/ylUAAIBPl8e/Y4yXAAAAjOXx7xjjJQAAAGN5/DvGeAkAAMBYHv+OMV4CAAAwlse/Y4yXAAAAjOXx7xjjJQAAAGN5/DvGeAkAAMBYHv+OMV4CAAAwlse/Y4yXAAAAjOXx75jrx0sAAAAojJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAWMB4CQAAwALGSwAAABYwXgIAALCA8RIAAIAFjJcAAAAsYLwEAABgAeMlAAAACxgvAQAAuNL//Nf/+e3Pvo218RIAAIBrxGyZvsbWeAkAAMDFmtkyMV4CAABwmX62TIyXAAAAXKCeLWMddeMlAAAAR/WzZawT4yUAAACHTGbLxHgJAADAvvlsmRgvAQAA2LE1W8b63GK8BAAAYGo+W8Y6MV4CAAAwU8+QW+vEeAkAAMACxksAAAAWMF4CAACwwDe//cffioiIiIiIiNyUf/zt/w98ccMkj9SOXQAAAABJRU5ErkJggg=="
    };
		
		$http({
			method : "post",
			url : "http://10.242.50.49:1988/mailservice/sendmail",
			data : JSON.stringify(datamail)
		}).then(function(response) {
			//console.log(response.data)
		},errorCallback);
	}

}]);

function commentBox(threadId){
	var data = {};
	data.threadId = threadId;
	$('#comments-container').comments({
		// enableAttachments: false,
		enableDeleting: false,
		enableNavigation: false,
		enableUpvoting: false,
		enableEditing: false,
	    profilePictureURL: 'img/user-icon.png',
	    getComments: function(success, error) {
	    	data.action = "getAllComments";
	    	
	    	$.ajax({
	            type: 'get',
	            url: 'action',
	            data: data,
	            success: function(comment) {
	            	//console.log(comment);
	            	comment = JSON.parse(comment);
	                success(comment.comments);
	            },
	            error: error
	        });
	        /*var commentsArray = [{
	        	
	            created: '2015-10-01',
	            content: 'Lorem ipsum dolort sit amet',
	            fullname: 'Simon Powell',
	            upvote_count: 2,
	            user_has_upvoted: false
	        }];
	        success(commentsArray);*/
	    },
	    postComment: function(commentJSON, success, error) {
	    	//console.log(commentJSON);
	    	data.action = "addNewComment";
	    	commentJSON.fullname= sessionStorage.getItem("username");
	    	data.commentjson = JSON.stringify(commentJSON);
	       $.ajax({
	            type: 'post',
	            url: 'action',
	            data: data,
	            success: function(comment) {
	            	comment = JSON.parse(comment);
	            	success(comment);   
	            },
	            error: error
	        });
	    },
	    /* putComment: function(commentJSON, success, error) {
	    	console.log(commentJSON);
	    	data.action = "addNewComment";
	    	data.commentjson = JSON.stringify(commentJSON);
	        $.ajax({
	            type: 'post',
	            url: '/api/comments/' + commentJSON.id,
	            data: commentJSON,
	            success: function(comment) {
	                success(comment)
	            },
	            error: error
	        });
	    },
	     upvoteComment: function(commentJSON, success, error) {
	    	console.log(commentJSON);	
	        var commentURL = '/api/comments/' + commentJSON.id;
	        var upvotesURL = commentURL + '/upvotes/';

	        if(commentJSON.userHasUpvoted) {
	            $.ajax({
	                type: 'post',
	                url: upvotesURL,
	                data: {
	                    comment: commentJSON.id
	                },
	                success: function() {
	                    success(commentJSON)
	                },
	                error: error
	            });
	        } else {
	            $.ajax({
	                type: 'delete',
	                url: upvotesURL + upvoteId,
	                success: function() {
	                    success(commentJSON)
	                },
	                error: error
	            });
	        }
	    }*/
	});
}


