var webpage="";
var hasSessionUser = sessionStorage.hasOwnProperty("username");
var sessionUserName = sessionStorage.getItem("username");
function supportstorage() {
	if (typeof window.localStorage=='object') 
		return true;
	else
		return false;		
}

function handleSaveLayout() {
	var e = $(".demo").html();
	if (!stopsave && e != window.demoHtml) {
		stopsave++;
		window.demoHtml = e;
		saveLayout();
		stopsave--;
	}
}

var layouthistory; 
function saveLayout(){
	var data = layouthistory;
	if (!data) {
		data={};
		data.count = 0;
		data.list = [];
	}
	if (data.list.length>data.count) {
		for (i=data.count;i<data.list.length;i++)
			data.list[i]=null;
	}
	data.list[data.count] = window.demoHtml;
	data.count++;
	if (supportstorage()) {
		localStorage.setItem("layoutdata",JSON.stringify(data));
	}
	layouthistory = data;
	//console.log(data);
	/*$.ajax({  
		type: "POST",  
		url: "/build/saveLayout",  
		data: { layout: $('.demo').html() },  
		success: function(data) {
			//updateButtonsVisibility();
		}
	});*/
		
	undoRedoBtns();
	
}

function downloadLayout(){
	
	$.ajax({  
		type: "POST",  
		url: "/build/downloadLayout",  
		data: { layout: $('#download-layout').html() },  
		success: function(data) { window.location.href = '/build/download'; }
	});
}

function downloadHtmlLayout(){
	$.ajax({  
		type: "POST",  
		url: "/build/downloadLayout",  
		data: { layout: $('#download-layout').html() },  
		success: function(data) { window.location.href = '/build/downloadHtml'; }
	});
}

function undoLayout() {
	var data = layouthistory;
	//console.log(data);
	if (data) {
		if (data.count<2) return false;
		window.demoHtml = data.list[data.count-2];
		data.count--;
		$('.demo').html(window.demoHtml);
		if (supportstorage()) {
			localStorage.setItem("layoutdata",JSON.stringify(data));
		}
		

		return true;
	}
	return false;
	/*$.ajax({  
		type: "POST",  
		url: "/build/getPreviousLayout",  
		data: { },  
		success: function(data) {
			undoOperation(data);
		}
	});*/
}

function redoLayout() {
	var data = layouthistory;
	if (data) {
		if (data.list[data.count]) {
			window.demoHtml = data.list[data.count];
			data.count++;
			$('.demo').html(window.demoHtml);
			if (supportstorage()) {
				localStorage.setItem("layoutdata",JSON.stringify(data));
			}
			return true;
		}
	}
	return false;
	/*
	$.ajax({  
		type: "POST",  
		url: "/build/getPreviousLayout",  
		data: { },  
		success: function(data) {
			redoOperation(data);
		}
	});*/
}

function saveToDB(){
	var data = {};
	
	$(".loading").removeClass("hide");
	
	var id = $("#sourcedbsave").attr("data-projectid");
	
	html2canvas(document.getElementsByClassName("demo"), {
	    onrendered: function(canvas) {
	    	data.preview = canvas.toDataURL("image/png");
	    }
	});
	
	if (supportstorage()) {
		localStorage.setItem("layoutdata",JSON.stringify(data));
	}

	data.html = window.demoHtml.trim()
	data.type="HTML"
	//console.log(window.demoHtml);
	var action = "";
	if(id === ""){
		action = "addProject";

	}else {
		action = "editProject";

		data.objectId = id;
	}
	
	setTimeout(function(){
		data = JSON.stringify(data);
		//console.log(data);
		$.ajax({
			type : "POST",
			url : "/Whiteboard/action",
			data : {project : data, action : action},
			success : function(data) {
				//console.log(data);
				data = JSON.parse(data);
				//console.log(data.objectId);
				$("#sourcedbsave").attr("data-projectid", data.objectId);
				$(".loading").addClass("hide");
				alert("Saved");
			}
		});
	}, 500);
	
}

function handleJsIds() {
	handleModalIds();
	handleAccordionIds();
	handleCarouselIds();
	handleTabsIds();
}
function handleAccordionIds() {
	var e = $(".demo #myAccordion");
	var t = randomNumber();
	var n = "accordion-" + t;
	var r;
	e.attr("id", n);
	e.find(".accordion-group").each(function(e, t) {
		r = "accordion-element-" + randomNumber();
		$(t).find(".accordion-toggle").each(function(e, t) {
			$(t).attr("data-parent", "#" + n);
			$(t).attr("href", "#" + r)
		});
		$(t).find(".accordion-body").each(function(e, t) {
			$(t).attr("id", r)
		})
	})
}
function handleCarouselIds() {
	var e = $(".demo #myCarousel");
	var t = randomNumber();
	var n = "carousel-" + t;
	e.attr("id", n);
	e.find(".carousel-indicators li").each(function(e, t) {
		$(t).attr("data-target", "#" + n)
	});
	e.find(".left").attr("href", "#" + n);
	e.find(".right").attr("href", "#" + n)
}
function handleModalIds() {
	var e = $(".demo #myModalLink");
	var t = randomNumber();
	var n = "modal-container-" + t;
	var r = "modal-" + t;
	e.attr("id", r);
	e.attr("href", "#" + n);
	e.next().attr("id", n)
}
function handleTabsIds() {
	var e = $(".demo #myTabs");
	var t = randomNumber();
	var n = "tabs-" + t;
	e.attr("id", n);
	e.find(".tab-pane").each(function(e, t) {
		var n = $(t).attr("id");
		var r = "panel-" + randomNumber();
		$(t).attr("id", r);
		$(t).parent().parent().find("a[href=#" + n + "]").attr("href", "#" + r)
	})
}
function randomNumber() {
	return randomFromInterval(1, 1e6)
}
function randomFromInterval(e, t) {
	return Math.floor(Math.random() * (t - e + 1) + e)
}
function gridSystemGenerator() {
	$(".lyrow .preview input").bind("keyup", function() {
		var e = 0;
		var t = "";
		var n = $(this).val().split(" ", 12);
		$.each(n, function(n, r) {
			e = e + parseInt(r);
			t += '<div class="col-sm-' + r + ' column"></div>'
		});
		if (e == 12) {
			$(this).parent().next().children().html(t);
			$(this).parent().prev().show()
		} else {
			$(this).parent().prev().hide()
		}
	})
}
function configurationElm(e, t) {
	$(".demo").delegate(".configuration > a", "click", function(e) {
		e.preventDefault();
		var t = $(this).parent().next().next().children();
		$(this).toggleClass("active");
		t.toggleClass($(this).attr("rel"))
	});
	$(".demo").delegate(".configuration .dropdown-menu a", "click", function(e) {
		e.preventDefault();
		var t = $(this).parent().parent();
		var n = t.parent().parent().next().next().children();
		t.find("li").removeClass("active");
		$(this).parent().addClass("active");
		var r = "";
		t.find("a").each(function() {
			r += $(this).attr("rel") + " "
		});
		t.parent().removeClass("open");
		n.removeClass(r);
		n.addClass($(this).attr("rel"))
	})
}
function removeElm() {
	$(".demo").delegate(".remove", "click", function(e) {
		e.preventDefault();
		$(this).parent().remove();
		if (!$(".demo .lyrow").length > 0) {
			clearDemo()
		}
	})
}
function clearDemo() {
	$(".demo").empty();
	layouthistory = null;
	if (supportstorage())
		localStorage.removeItem("layoutdata");
}
function removeMenuClasses() {
	$("#menu-layoutit li button").removeClass("active")
}
function changeStructure(e, t) {
	$("#download-layout ." + e).removeClass(e).addClass(t)
}
function cleanHtml(e) {
	$(e).parent().append($(e).children().html())
}
function downloadLayoutSrc() {
	var e = "";
	$("#download-layout").children().html($(".demo").html());
	var t = $("#download-layout").children();
	t.find(".preview, .configuration, .drag, .remove").remove();
	t.find(".lyrow").addClass("removeClean");
	t.find(".box-element").addClass("removeClean");
	t.find(".lyrow .lyrow .lyrow .lyrow .lyrow .removeClean").each(function() {
		cleanHtml(this)
	});
	t.find(".lyrow .lyrow .lyrow .lyrow .removeClean").each(function() {
		cleanHtml(this)
	});
	t.find(".lyrow .lyrow .lyrow .removeClean").each(function() {
		cleanHtml(this)
	});
	t.find(".lyrow .lyrow .removeClean").each(function() {
		cleanHtml(this)
	});
	t.find(".lyrow .removeClean").each(function() {
		cleanHtml(this)
	});
	t.find(".removeClean").each(function() {
		cleanHtml(this)
	});
	t.find(".removeClean").remove();
	$("#download-layout .column").removeClass("ui-sortable");
	$("#download-layout .row-fluid").removeClass("clearfix").children().removeClass("column");
	if ($("#download-layout .container").length > 0) {
		changeStructure("row-fluid", "row")
	}
	formatSrc = $.htmlClean($("#download-layout").html(), {
		format: true,
		allowedAttributes: [
			["id"],
			["class"],
			["style"],
			["data-toggle"],
			["data-target"],
			["data-parent"],
			["role"],
			["data-dismiss"],
			["aria-labelledby"],
			["aria-hidden"],
			["data-slide-to"],
			["data-slide"],
			["data-chart"]
		]
	});
	$("#download-layout").html(formatSrc);
	$("#downloadModal textarea").empty();
	$("#downloadModal textarea").val(formatSrc)
	webpage = formatSrc;
}

var currentDocument = null;
var timerSave = 1000;
var stopsave = 0;
var startdrag = 0;
var demoHtml = $(".demo").html();
var currenteditor = null;
$(window).resize(function() {
	$("body").css("min-height", $(window).height() - 90);
	$(".demo").css("min-height", $(window).height() - 160)
});

function restoreData(){
	if (supportstorage()) {
		layouthistory = JSON.parse(localStorage.getItem("layoutdata"));
		if (!layouthistory) return false;
		window.demoHtml = layouthistory.list[layouthistory.count-1];
		if (window.demoHtml) $(".demo").html(window.demoHtml);
	}
}

function initContainer(){
	$(".demo, .demo .column").sortable({
		connectWith: ".column",
		opacity: .35,
		handle: ".drag",
		start: function(e,t) {
			if (!startdrag) stopsave++;
			startdrag = 1;
		},
		stop: function(e,t) {
			if(stopsave>0) stopsave--;
			startdrag = 0;
			
		}
	});
	configurationElm();
}

function undoRedoBtns(){
	var data = layouthistory;
	//console.log(data);
	if (data.count === 1) {
		$("#undo").addClass("active");
	} else {
		$("#undo").removeClass("active");
	}
	if (!data.list[data.count]) {
		$("#redo").addClass("active");
	} else {
		$("#redo").removeClass("active");
	}
}

function saveHtml(){
				//			webpage = '<html>\n<head>\n<script type="text/javascript" src="http://www.francescomalagrino.com/BootstrapPageGenerator/3/js/jquery-2.0.0.min.js"></script>\n<script type="text/javascript" src="http://www.francescomalagrino.com/BootstrapPageGenerator/3/js/jquery-ui"></script>\n<link href="http://www.francescomalagrino.com/BootstrapPageGenerator/3/css/bootstrap-combined.min.css" rel="stylesheet" media="screen">\n<script type="text/javascript" src="http://www.francescomalagrino.com/BootstrapPageGenerator/3/js/bootstrap.min.js"></script>\n</head>\n<body>\n'+ webpage +'\n</body>\n</html>'
	
				//webpage = '<html>\n<head>\n<script src="https://code.jquery.com/jquery-3.1.0.js" integrity="sha256-slogkvB1K3VOkzAI8QITxV3VzpOnkeNVsKvtkYLMjfk=" crossorigin="anonymous"></script>\n<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">\n<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>\n</head>\n<body>\n' + webpage + '\n</body>\n</html>'
				
				
				webpage = '<html><head><script src="https://code.jquery.com/jquery-3.1.0.js" integrity="sha256-slogkvB1K3VOkzAI8QITxV3VzpOnkeNVsKvtkYLMjfk=" crossorigin="anonymous"></script><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"><script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script></head>\n<body>' 
					+ webpage + 
					'<link href="'+ window.location.origin+'/Whiteboard/editor/css/c3.min.css" rel="stylesheet"/>'+
					'<script src="'+ window.location.origin+'/Whiteboard/editor/js/d3.min.js"></script>'+ 
					'<script src="'+ window.location.origin+'/Whiteboard/editor/js/c3.min.js"></script>'+ 
					'<script src="'+ window.location.origin+'/Whiteboard/editor/js/chartsExport.js"></script>'+  
					'</body></html>'
					/* FM aka Vegetam Added the function that save the file in the directory Downloads. Work only to Chrome Firefox And IE*/
				if (navigator.appName == "Microsoft Internet Explorer" && window.ActiveXObject) {
					var locationFile = location.href.toString();
					var dlg = false;
					with(document) {
						ir = createElement('iframe');
						ir.id = 'ifr';
						ir.location = 'about.blank';
						ir.style.display = 'none';
						body.appendChild(ir);
						with(getElementById('ifr').contentWindow.document) {
							open("text/html", "replace");
							charset = "utf-8";
							write(webpage);
							close();
							document.charset = "utf-8";
							dlg = execCommand('SaveAs', false, locationFile + "webpage.html");
						}
						return dlg;
					}
				} else {
					webpage = webpage;
					var blob = new Blob([webpage], {
						type: "text/html;charset=utf-8"
					});
					saveAs(blob, "webpage.html");
				}
}


$(document).ready(function() {
	
	if(!hasSessionUser){
		window.location.href="/Whiteboard";
	}

	//alert("dom");
	var template = localStorage.getItem("template");
	var id = localStorage.getItem("projectId");
	$("#sourcedbsave").attr( "data-projectId", id );
	if(template.length < 100 && template!== ""){
		$(".demo").load(template);
	}else{
		$(".demo").html(template);
	}
	
	setTimeout(function(){
		documentLoadFunction();
		
		$.each($(".wb-chart-lib"),function( i, val ) {
			var domObj = val;
			eval("wbC3Chart.c3"+$(domObj).data("chart")+"(domObj)");
		});
	},300);
	
	
	
});

$(document).on("change",".add_image",function(e){
	//console.log("add_image");
	var $imgTag=$(this).parent().parent().parent().children("div.view").find("img");
	 var reader = new FileReader();
	    
	    reader.onload = function (event) { 
	        $.ajax({  
	    		type: "POST",  
	    		url: "/Whiteboard/action",  
	    		data: { action:"addImage", imagebase64: event.target.result, username: sessionStorage.getItem("username") },  
	    		success: function(data) { 
	    			//console.log(window.location.origin+"/Whiteboard/action?action=getImage&id="+data);
			        $imgTag.attr("src",window.location.origin+"/Whiteboard/action?action=getImage&id="+data);	   
	    		}
	    	});   
	    }
	    reader.readAsDataURL(e.target.files[0]);
});

var documentLoadFunction = function(){

//window.onload = function(){
	//alert("onload");
	//CKEDITOR.disableAutoInline = true;
	restoreData();
	//CKEDITOR.extraPlugins = 'sourcedialog';
	//var contenthandle = CKEDITOR.replace( 'editor1' );
//	var contenthandle =CKEDITOR.replace( 'contenteditor' ,{
//		language: 'en',
//		contentsCss: ['css/bootstrap.min.css'],
//		allowedContent: true
//	});
	$("body").css("min-height", $(window).height() - 90);
	$(".demo").css("min-height", $(window).height() - 160);
	$(".sidebar-nav .lyrow").draggable({
		connectToSortable: ".demo",
		helper: "clone",
		handle: ".drag",
		start: function(e,t) {
			if (!startdrag) stopsave++;
			startdrag = 1;
		},
		drag: function(e, t) {
			t.helper.width(400)
		},
		stop: function(e, t) {
			$(".demo .column").sortable({
				opacity: .35,
				connectWith: ".column",
				start: function(e,t) {
					if (!startdrag) stopsave++;
					startdrag = 1;
				},
				stop: function(e,t) {
					if(stopsave>0) stopsave--;
					startdrag = 0;
				}
			});
			if(stopsave>0) stopsave--;
			startdrag = 0;
		}
	});
	$(".sidebar-nav .box").draggable({
		connectToSortable: ".column",
		helper: "clone",
		//handle: ".drag",
		start: function(e,t) {
			if (!startdrag) stopsave++;
			startdrag = 1;
		
		},
		drag: function(e, t) {
			t.helper.width(400)
		},
		stop: function(e, t) {
			handleJsIds();
			if($(t.helper[0]).hasClass("wb-chart")){
				initWbChart();
			}
			if(stopsave>0) stopsave--;
			startdrag = 0;
				
		}
	});
	initContainer();
	$('body.edit .demo').on("click","[data-target=#editorModal]",function(e) {
		e.preventDefault();
		currenteditor = $(this).parent().parent().find('.view');
		var eText = currenteditor.html();
		contenthandle.setData(eText);
	});
	$("#savecontent").click(function(e) {
		e.preventDefault();
		currenteditor.html(contenthandle.getData());
	});
	$("[data-target=#downloadModal]").click(function(e) {
		e.preventDefault();
		downloadLayoutSrc();
	});
	$("[data-target=#shareModal]").click(function(e) {
		e.preventDefault();
		handleSaveLayout();
	});
	$("#download").click(function() {
		downloadLayout();
		return false
	});
	$("#downloadhtml").click(function() {
		downloadHtmlLayout();
		return false
	});
	$("#edit").click(function() {
		$("body").removeClass("devpreview sourcepreview");
		$("body").addClass("edit");
		removeMenuClasses();
		$("#comments-container").removeClass("show");
		$("#comments-container").addClass("hide");
		$("#comments-container").empty();
		return false
	});
	$("#clear").click(function(e) {
		e.preventDefault();
		clearDemo()
	});
	$("#devpreview").click(function() {
		$("body").removeClass("edit sourcepreview");
		$("body").addClass("devpreview");
		removeMenuClasses();
		$("#comments-container").removeClass("hide");
		$("#comments-container").addClass("show");
		commentBox();
		$(this).addClass("active");
		return false
	});
	$("#sourcepreview").click(function() {
		$("body").removeClass("edit");
		$("body").addClass("devpreview sourcepreview");
		removeMenuClasses();
		$(this).addClass("active");
		return false
	});
	$("#fluidPage").click(function(e) {
		e.preventDefault();
		changeStructure("container", "container-fluid");
		$("#fixedPage").removeClass("active");
		$(this).addClass("active");
		downloadLayoutSrc()
	});
	$("#fixedPage").click(function(e) {
		e.preventDefault();
		changeStructure("container-fluid", "container");
		$("#fluidPage").removeClass("active");
		$(this).addClass("active");
		downloadLayoutSrc()
	});
	
	$("#downloadSource").click(function(e){
		e.preventDefault();
		saveHtml();
	});
	
	$(".nav-header").click(function() {
		$(".sidebar-nav .boxes, .sidebar-nav .rows").hide();
		$(this).next().slideDown()
	});
	$('#undo').click(function(){
		stopsave++;
			
			
		if (undoLayout()){
			initContainer();
		}
		
		undoRedoBtns()
		
		stopsave--;
		//console.log(stopsave);
	});
	$('#redo').click(function(){
		stopsave++;
		
		if (redoLayout()){
			initContainer();
		}
		
		undoRedoBtns()
		
		stopsave--;
		//console.log(stopsave);
	});
	removeElm();
	gridSystemGenerator();
	setInterval(function() {
		handleSaveLayout()
	}, timerSave)
	
	
	$(".editor").click(function(){
		$(".editor").removeClass("active");
		$(this).toggleClass("active");
	});
	
	$(".hasDatepicker").removeClass("hasDatepicker");
	
	$("#sourcedbsave").click(function(){
		saveToDB();
	});
	
	
//	$('[data-toggle="tooltip"]').tooltip();
}

function initCommentBox(){
	var data = {};
	data.action = "addThread";
	$.ajax({
		type : 'post',
		url : '/Whiteboard/action',
		data : data,
		success : function(comment) {
			comment = JSON.parse(comment);
			commentBox(comment["objectId"]);
		}
	});
}


function commentBox(){
	var data = {};
	data.threadId = localStorage.getItem("commentId");
	$('#comments-container').comments({
		// enableAttachments: false,
		enableDeleting: false,
		enableNavigation: false,
		enableUpvoting: false,
		enableEditing: true,
		createdByCurrentUser : false,
	    profilePictureURL: 'img/user-icon.png',
	    getComments: function(success, error) {
	    	data.action = "getAllComments";
	    	$.ajax({
	            type: 'get',
	            url: '/Whiteboard/action',
	            data: data,
	            success: function(comment) {
	            	//console.log(comment);
	            	comment = JSON.parse(comment);
	                success(comment.comments);
	            },
	            error: error
	        });

	    },
	    postComment: function(commentJSON, success, error) {
	    	//console.log(commentJSON);
	    	commentJSON.fullname = sessionStorage.getItem("username");
	    	commentJSON.created_by_current_user = false;
	    	data.action = "addNewComment";
	    	data.commentjson = JSON.stringify(commentJSON);
	    	//console.log(commentJSON);
	       $.ajax({
	            type: 'post',
	            url: '/Whiteboard/action',
	            data: data,
	            success: function(comment) {
	            	comment = JSON.parse(comment);
	            	success(comment);   
	            },
	            error: error
	        });
	    },

	});
}


	
//})