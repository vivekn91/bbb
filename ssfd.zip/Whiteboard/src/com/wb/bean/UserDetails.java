package com.wb.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UserDetails {

	private String userid;
	private String userName;
	private String password;
	private boolean isUserValid;
	private boolean isPasswordValid;
	private String ctsUserId;
	private String email;
	private String displayName;
	private String fullName;
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getUserid() {
		return userid;
	}

	@XmlElement
	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUserName() {
		return userName;
	}

	@XmlElement
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	@XmlElement
	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isUserValid() {
		return isUserValid;
	}

	@XmlElement
	public void setUserValid(boolean isUserValid) {
		this.isUserValid = isUserValid;
	}

	public boolean isPasswordValid() {
		return isPasswordValid;
	}

	@XmlElement
	public void setPasswordValid(boolean isPasswordValid) {
		this.isPasswordValid = isPasswordValid;
	}
	public String getCtsUserId() {
		return ctsUserId;
	}

	public void setCtsUserId(String ctsUserId) {
		this.ctsUserId = ctsUserId;
	}
	
	public String getFullName(){
		return fullName;
	}
	
	public void setFullName(String fullName){
		this.fullName = fullName;
	}

}
