package com.wb.dao;


import java.util.logging.Level;
import java.util.logging.Logger;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

public class MongoDAO {

	private static final int port = 27017;
	private static final String host = "localhost";
	
	private static MongoClient mongoClient;
	private static MongoDatabase database;
	
	/*
	String user;        // the user name
	String databaseStr;    // the name of the database in which the user is defined
	char[] password;    // the password as a character array
	// ...
	MongoCredential credential = MongoCredential.createCredential(user,
	                                                              databaseStr,
	                                                              password);
	*/
	
	static{
		if(mongoClient==null){
			try {
				mongoClient = new MongoClient(host, port);

				database = mongoClient.getDatabase("test");
			} catch (Exception e) {
				Logger.getLogger("com.dao").log(Level.SEVERE, e.getMessage(), e);
			}
		}
	}
	
	public static MongoDatabase getDBObj(){
		return database;
	}
	
	
}
