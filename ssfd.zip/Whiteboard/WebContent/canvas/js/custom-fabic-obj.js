fabric.CommentImage = fabric.util.createClass(fabric.Image, {

  type: 'comment-image',

  initialize: function(element, options) {
    this.callSuper('initialize', element, options);
    options && this.set('commentId', options.commentId);
  },

  toObject: function() {
    return fabric.util.object.extend(this.callSuper('toObject'), { commentId: this.commentId });
  }
});

fabric.CommentImage.fromObject = function(object, callback) {
	  fabric.util.loadImage(object.src, function(img) {
	    callback && callback(new fabric.CommentImage(img, object));
	  });
};
	
fabric.CommentImage.async = true;


