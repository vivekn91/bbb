/* 
 * This file holds the angular js relates stuff
 */

var app = angular.module("wbApp", ['ngRoute']);


app.config(function ($routeProvider) {
    $routeProvider
            .when("/", {
                templateUrl: "partials/about.html"
            })
            .when("/configure", {
                templateUrl: "partials/configure.html",
                controller: "configureController"
            });
});

app.controller("aboutController", ["$scope", function ($scope) {


    }]);

app.controller("configureController", ["$scope", function ($scope) {

        $scope.framework = [
            {img: "img/bootstrap-logo.png", title: "Bootstrap", category: "framework", isSelected: false},
            {img: "img/materialize_logo.png", title: "Materialize CSS", category: "framework", isSelected: false}
        ];
        $scope.plugins = [
            {img: "img/logo-jquery.png", title: "jQuery", category: "plugin", isSelected: false},
            {img: "img/jqeryui-logo.png", title: "jQueryUI", category: "plugin", isSelected: false},
            {img: "img/d3-logo.png", title: "D3 Chart", category: "plugin", isSelected: false},
            {img: "img/highchart-logo.png", title: "Highchart", category: "plugin", isSelected: false}
        ];

        $scope.toggleSelection = function (isSelected) {
            isSelected = ($scope.isSelected === false) ? true : false;
        };

    }]);


