package com.wb.manager;

import java.util.Hashtable;
import java.util.logging.Logger;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import com.wb.bean.UserDetails;



public class LDAPDataAccessManager {

	private static final String dbURL = "ldap://10.237.5.183:389/dc=cts,dc=com";
	private static final String dbDriver = "com.sun.jndi.ldap.LdapCtxFactory";
	private static DirContext ctx = null;
	private static final String CTS_APPENDER = "cts\\";
	private static final String CTS_VALUE = "cts";

	private static LDAPDataAccessManager instance = null;

	static Logger log = Logger.getLogger(LDAPDataAccessManager.class.getName());

	private LDAPDataAccessManager(UserDetails details) {

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, dbDriver);
		env.put(Context.PROVIDER_URL, dbURL);
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, details.getCtsUserId());
		env.put(Context.SECURITY_CREDENTIALS, details.getPassword());

		try {
			ctx = new InitialDirContext(env);
		} catch (Exception e) {
			//log.info("LDAP Connectivity exception");
			//log.logp(java.util.logging.Level.SEVERE,"LDAPDataAccessManager" , "LDAPDataAccessManager", e.getMessage(),e);
			//e.printStackTrace();
		}
	}

	public static UserDetails editUserDetails(UserDetails details) {

		if (details.getUserid().startsWith(CTS_VALUE)) {
			details.setUserid(details.getUserid().replace("\\", "-").split("-")[1]);
			details.setCtsUserId(CTS_APPENDER + details.getUserid());
		} else {
			details.setCtsUserId(CTS_APPENDER + details.getUserid());
		}
		return details;
	}

	public static LDAPDataAccessManager getInstance(UserDetails details) {
		if (instance == null)
			return new LDAPDataAccessManager(details);
		else
			return instance;
	}

	public DirContext getContext() {
		return ctx;
	}

	public void closeContext() {
		if (ctx != null) {
			try {
				if (ctx != null) {
					ctx.close();
				}
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}
