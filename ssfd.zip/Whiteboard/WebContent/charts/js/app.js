
/********************************************/
/****************CONTROLLER******************/
/********************************************/
var app = angular.module("chartEditor", []);

app.run(function($rootScope) {
    $rootScope.hasSessionUser = sessionStorage.hasOwnProperty("username");
    $rootScope.sessionUserName = sessionStorage.getItem("username");
    
});

app.controller("chartController", ["$rootScope","$scope","$timeout", function ($rootScope,$scope,$timeout) {
	

	if(!$rootScope.hasSessionUser){
		//window.location.href="/Whiteboard";
	}
}]);



