var canvas, mousePos;
/*
Delete
Uplaod a file
Upload from URL

*/
(function (global) {
	function capitalize(string) {
		return string.charAt(0).toUpperCase() + string.slice(1);
	}


	function pad(str, length) {
		while (str.length < length) {
			str = '0' + str;
		}
		return str;
	}

	var getRandomInt = fabric.util.getRandomInt;

	function getRandomColor() {
		return (
			pad(getRandomInt(0, 255).toString(16), 2) +
			pad(getRandomInt(0, 255).toString(16), 2) +
			pad(getRandomInt(0, 255).toString(16), 2)
		);
	}

	global.capitalize = capitalize;
	global.getRandomColor = getRandomColor;

})(this);


function addBackgroundImage(path) {
	
	
	canvas.setBackgroundImage(path, canvas.renderAll.bind(canvas), {
		originX: 'left',
		originY: 'top',
		left: 0,
		top: 0,
		width: canvas.width,
		height: canvas.height
	});

};

function addImage(path, x, y) {
	fabric.Image.fromURL(path, function (image) {

		image.set({
				left: x,
				top: y
					//angle: getRandomInt(-10, 10)
			})
			//.scale(getRandomNum(minScale, maxScale))
			//.setCoords();

		canvas.add(image);
		//canvas.setActiveObject(image);
	});

};

var addText = function (x, y) {
	var text = 'Sample text';

	var textSample = new fabric.Text(text.slice(0, 9), {
		left: x,
		top: y,
		fontFamily: "helvetica",
		scaleX: 0.5,
		scaleY: 0.5,
		fontWeight: '',
		originX: 'left',
		hasRotatingPoint: true,
		centerTransform: true
	});

	canvas.add(textSample);
	//canvas.setActiveObject(textSample);
};

var addRect = function (x, y) {
	var rect = new fabric.Rect({
		left: x,
		top: y,
		fill: '#' + getRandomColor(),
		width: 50,
		height: 50,
		opacity: 0.8
	});
	canvas.add(rect);
	//canvas.setActiveObject(rect);
};

var addCircle = function (x, y) {
	var circle = new fabric.Circle({
		left: x,
		top: y,
		fill: '#' + getRandomColor(),
		radius: 50,
		opacity: 0.8
	});
	canvas.add(circle);
	//canvas.setActiveObject(circle);
};

var addTriangle = function (x, y) {
	var triangle = new fabric.Triangle({
		left: x,
		top: y,
		fill: '#' + getRandomColor(),
		width: 50,
		height: 50,
		opacity: 0.8
	});

	canvas.add(triangle);
	//canvas.setActiveObject(triangle);
};

var addLine = function (x, y) {
	var line = new fabric.Line([50, 100, 200, 200], {
		left: x,
		top: y,
		stroke: '#' + getRandomColor()
	});

	canvas.add(line);
	//canvas.setActiveObject(line);
};

var addPolygon = function (x, y) {
	var polygen = new fabric.Polygon([
		{
			x: 185,
			y: 0
		},
		{
			x: 250,
			y: 100
		},
		{
			x: 385,
			y: 170
		},
		{
			x: 0,
			y: 245
		}], {
		left: x,
		top: y,
		fill: '#' + getRandomColor()
	});
	canvas.add(polygen);
	//canvas.setActiveObject(polygen);

};

var addTextType = function (x, y) {
	var ItextObj = new fabric.IText('Double click and Type', {
		left: x,
		top: y,
		fontFamily: 'arial black',
		fontSize: 16,
	})
	canvas.add(ItextObj);
	//canvas.setActiveObject(ItextObj);
}

var addComments = function (x, y) {
	var imgObj = new Image();
	imgObj.src = "images/stencils/Common/Icons/balloon.png";
	imgObj.onload = function () {
		
	var data = {};
	data.act = "addComments"
	data.action = "addThread";
	$.ajax({
		type : 'post',
		url : '/Whiteboard/action',
		data : data,
		success : function(comment) {
			comment = JSON.parse(comment);
			var commentImg = new fabric.CommentImage(imgObj, { commentId: comment["objectId"] });
			commentImg.set({
				left: x,
				top: y
			});
			canvas.add(commentImg);
		}
	});
	}
}


function saveToDB(canvasJSON){
	var data = {};
	
	$(".loading").removeClass("hide");
	
	var id = $("#save_canvas").attr("data-projectid");

	
	/*if (supportstorage()) {
		localStorage.setItem("layoutdata",JSON.stringify(data));
	}*/

	data.html = canvasJSON;
	data.type="Canvas";
	data.preview="img/canvas.jpg";
	//console.log(canvasJSON);
	var action = "";
	if(id === "" || id === undefined){
		action = "addProject";
	}else {
		action = "editProject";
		data.objectId = id;
	}

	data = JSON.stringify(data);
	$.ajax({
		type : "POST",
		url : "/Whiteboard/action",
		data : {project : data, action : action},
		success : function(data) {
			//console.log(data);
			data = JSON.parse(data);
			//console.log(data.objectId);
			$("#save_canvas").attr("data-projectid", data.objectId);
			$(".loading").addClass("hide");
			alert("Saved");
		}
	});
	
}



  var loadJSON = function(json) {
    canvas.loadFromJSON(json, function(){
      canvas.renderAll();
    });
  };


/***************************************************/

function getActiveStyle(styleName, object) {
	object = object || canvas.getActiveObject();
	if (!object) return '';

	return (object.getSelectionStyles && object.isEditing) ? (object.getSelectionStyles()[styleName] || '') : (object[styleName] || '');
};

function setActiveStyle(styleName, value, object) {
	object = object || canvas.getActiveObject();
	if (!object) return;

	if (object.setSelectionStyles && object.isEditing) {
		var style = {};
		style[styleName] = value;
		object.setSelectionStyles(style);
		object.setCoords();
	} else {
		object[styleName] = value;
	}

	object.setCoords();
	canvas.renderAll();
};

function getActiveProp(name) {
	var object = canvas.getActiveObject();
	if (!object) return '';

	return object[name] || '';
}

function setActiveProp(name, value) {
	var object = canvas.getActiveObject();
	if (!object) return;

	object.set(name, value).setCoords();
	canvas.renderAll();
}


function userActions($scope,$timeout) {

	$scope.getOpacity = function () {
		return getActiveStyle('opacity') * 100;
	};
	$scope.setOpacity = function (value) {
		setActiveStyle('opacity', parseInt(value, 10) / 100);
	};

	$scope.getFill = function () {
		return getActiveStyle('fill');
	};
	$scope.setFill = function (value) {
		setActiveStyle('fill', value);
	};

	$scope.setText = function (value) {
		setActiveProp('text', value);
	};

	$scope.getText = function () {
		return getActiveProp('text');
	};


	$scope.getBgColor = function () {
		return getActiveProp('backgroundColor');
	};
	$scope.setBgColor = function (value) {
		setActiveProp('backgroundColor', value);
	};

	$scope.getTextBgColor = function () {
		return getActiveProp('textBackgroundColor');
	};
	$scope.setTextBgColor = function (value) {
		setActiveProp('textBackgroundColor', value);
	};

	$scope.getStrokeColor = function () {
		return getActiveStyle('stroke');
	};
	$scope.setStrokeColor = function (value) {
		setActiveStyle('stroke', value);
	};

	$scope.getStrokeWidth = function () {
		return getActiveStyle('strokeWidth');
	};
	$scope.setStrokeWidth = function (value) {
		setActiveStyle('strokeWidth', parseInt(value, 10));
	};

	$scope.getFontSize = function () {
		return getActiveStyle('fontSize');
	};
	$scope.setFontSize = function (value) {
		setActiveStyle('fontSize', parseInt(value, 10));
	};

	$scope.getLineHeight = function () {
		return getActiveStyle('lineHeight');
	};
	$scope.setLineHeight = function (value) {
		setActiveStyle('lineHeight', parseFloat(value, 10));
	};
	$scope.getCharSpacing = function () {
		return getActiveStyle('charSpacing');
	};
	$scope.setCharSpacing = function (value) {
		setActiveStyle('charSpacing', value);
	};


	$scope.isBold = function () {
		return getActiveStyle('fontWeight') === 'bold';
	};
	$scope.toggleBold = function () {
		setActiveStyle('fontWeight',
			getActiveStyle('fontWeight') === 'bold' ? '' : 'bold');
	};
	$scope.isItalic = function () {
		return getActiveStyle('fontStyle') === 'italic';
	};
	$scope.toggleItalic = function () {
		setActiveStyle('fontStyle',
			getActiveStyle('fontStyle') === 'italic' ? '' : 'italic');
	};

	$scope.isUnderline = function () {
		return getActiveStyle('textDecoration').indexOf('underline') > -1;
	};
	$scope.toggleUnderline = function () {
		var value = $scope.isUnderline() ? getActiveStyle('textDecoration').replace('underline', '') : (getActiveStyle('textDecoration') + ' underline');

		setActiveStyle('textDecoration', value);
	};

	$scope.isLinethrough = function () {
		return getActiveStyle('textDecoration').indexOf('line-through') > -1;
	};
	$scope.toggleLinethrough = function () {
		var value = $scope.isLinethrough() ? getActiveStyle('textDecoration').replace('line-through', '') : (getActiveStyle('textDecoration') + ' line-through');

		setActiveStyle('textDecoration', value);
	};
	$scope.isOverline = function () {
		return getActiveStyle('textDecoration').indexOf('overline') > -1;
	};
	$scope.toggleOverline = function () {
		var value = $scope.isOverline() ? getActiveStyle('textDecoration').replace('overline', '') : (getActiveStyle('textDecoration') + ' overline');

		setActiveStyle('textDecoration', value);
	};


	$scope.getSelected = function () {
		return canvas.getActiveObject();
	};

	$scope.removeSelected = function () {
		var activeObject = canvas.getActiveObject(),
			activeGroup = canvas.getActiveGroup();

		if (activeGroup) {
			var objectsInGroup = activeGroup.getObjects();
			canvas.discardActiveGroup();
			objectsInGroup.forEach(function (object) {
				canvas.remove(object);
			});
		} else if (activeObject) {
			canvas.remove(activeObject);
		}
	};

	$scope.sendBackwards = function () {

		var activeObject = canvas.getActiveObject();
		if (activeObject) {
			canvas.sendBackwards(activeObject);
		}
	};

	$scope.sendToBack = function () {
		var activeObject = canvas.getActiveObject();
		if (activeObject) {
			canvas.sendToBack(activeObject);
		}
	};

	$scope.bringForward = function () {
		var activeObject = canvas.getActiveObject();
		if (activeObject) {
			canvas.bringForward(activeObject);
		}
	};

	$scope.bringToFront = function () {
		var activeObject = canvas.getActiveObject();
		if (activeObject) {
			canvas.bringToFront(activeObject);
		}
	};

	$scope.confirmClear = function () {
		if (confirm('Are you sure?')) {
			canvas.clear();
		}
	};

	$scope.rasterizeJSON = function () {
		//console.log(JSON.stringify(canvas));
		saveToDB(JSON.stringify(canvas));
	};


	$scope.getComments = function () {
		var val = getActiveProp("commentId") 
		if(val !== ""){
		commentBox(val);
		}
		return val;
	};


}


function watchCanvas($scope) {

	function updateScope() {
		$scope.$$phase || $scope.$digest();
		canvas.renderAll();
	}

	canvas
		.on('object:selected', updateScope)
		.on('group:selected', updateScope)
		.on('path:created', updateScope)
		.on('selection:cleared', updateScope);

}




/********************************************/
/****************CONTROLLER******************/
/********************************************/
var app = angular.module("canvasEditor", []);

app.run(function($rootScope) {
    $rootScope.hasSessionUser = sessionStorage.hasOwnProperty("username");
    $rootScope.sessionUserName = sessionStorage.getItem("username");
    
});


app.controller("useraction", ["$rootScope","$scope","$timeout", function ($rootScope,$scope,$timeout) {
	

	if(!$rootScope.hasSessionUser){
		window.location.href="/Whiteboard";
	}
	
	canvas = new fabric.Canvas('wb-canvas');


	canvas.on('mouse:down', function (options) {
		if (options.target) {
			//console.log('an object was clicked! ', options.target);
		}
	})

	$scope.canvas = canvas;
	$scope.getActiveStyle = getActiveStyle;
	//$scope.getCustomProp = getCustomProp;




	userActions($scope,$timeout);
	watchCanvas($scope);

    }]);

app.directive('bindCallTo', function () {
	return {
		restrict: 'A',

		link: function ($scope, $element, $attrs) {

			var prop = capitalize($attrs.bindCallTo),
				getter = 'get' + prop,
				setter = 'set' + prop;


			$element.on('change keyup select', function () {
				//console.log(setter);
				$scope[setter] && $scope[setter](this.value);
			});

			//			$element.on('keyup', function () {
			//				console.log(setter + "ON key UP" + this.value);
			//				console.log($scope[setter]);
			//				$scope[setter] && $scope[setter](this.value);
			//			});

			$scope.$watch($scope[getter], function (newVal) {
				if ($element[0].type === 'radio') {
					var radioGroup = document.getElementsByName($element[0].name);
					for (var i = 0, len = radioGroup.length; i < len; i++) {
						radioGroup[i].checked = radioGroup[i].value === newVal;
					}
				} else {
					//console.log(getter + "" + $element.val());
					$element.val(newVal);
				}
			});
		}
	};
});



/**********************************************/
/**************ONLOAD PAGE*************/
/**********************************************/



window.onload = function () {

	var template = localStorage.getItem("template");
	var id = localStorage.getItem("projectId");
	$("#save_canvas").attr( "data-projectId", id );

	
	
	//load json
	if(template!=="" && template!=="null"){
		//console.log(template);
		loadJSON(template);
	}else{
		canvas.setBackgroundImage("images/bg.jpg", canvas.renderAll.bind(canvas), {
		originX: 'left',
		originY: 'top',
		left: 0,
		top: 0,
		width: canvas.width,
		height: canvas.height
		});
	}


	setTimeout(function () {
		canvas.renderAll();
	}, 300);


	$('#wb-canvas').on("mousemove", function (e) {
		mousePos = {
			'x': e.layerX,
			'y': e.layerY
		};
		//console.log(mousePos);
	});


	$.get("sources2.json", function (data) {
		//console.log(data);
		var items = data;
		var keys = Object.keys(items);
		keys.forEach(function (val) {
			loadImages(val, data[val]);
		});

		//CALL draggable
		makeDrag();

		//for elements
		$('[data-toggle="tooltip"]').tooltip();

	}).done(function () {
		console.log("call success sources.json");

	}).error(function () {
		console.log("error while loading sources.json");
	});


	$('[data-toggle="tooltip"]').tooltip();
	
	$("#add_image").on("change",function(e){
		//console.log("add_image");
		 var reader = new FileReader();
		    reader.onload = function (event) { 
		    	//console.log('Image upload');
		        var imgObj = new Image();
		       
		        $.ajax({  
		    		type: "POST",  
		    		url: "/Whiteboard/action",  
		    		data: { action:"addImage", imagebase64: event.target.result, username: sessionStorage.getItem("username") },  
		    		success: function(data) { 
		    			// console.log(data)
		    			// console.log("?action=getImage&id=");
		    			imgObj.src = event.target.result;
		 		        var obj ={};
		 		       // obj.path = event.target.result;
		 		        obj.path = "/Whiteboard/action?action=getImage&id="+data;
				       // console.log(imgObj);
				        loadImages("savedItems", [obj]);
				        makeDrag();
		    		}
		    	});
		        
		    }
		    reader.readAsDataURL(e.target.files[0]);
	});
	
	$("#bg_canvas_add_image").on("change",function(e){
		var reader = new FileReader();
	    reader.onload = function (event) { 
	    	console.log('Image upload');
	        var imgObj = new Image();
	        imgObj.src = event.target.result;
	        var obj ={};
	        obj.path = event.target.result;
	        addBackgroundImage(event.target.result);

	    }
	    reader.readAsDataURL(e.target.files[0]);
	});


};

function makeDrag(){
	$(".wb_list_item").draggable({
		//containment: $('#wb-canvas'),
		helper: "clone",
		stop: function (ev, ui) {
			var finalOffset = $(this).offset();

			var x = ev.pageX - $('#wb-canvas').offset().left;
			var y = ev.pageY - $('#wb-canvas').offset().top;

			//console.log(x,y);
			//console.log($(ui.helper[0]).attr("src"))
			/*console.log(finalOffset);
			console.log($(ui.position));*/
			var category = $(ui.helper[0]).data("category");
			if (category === "wireframe") {
				addImage($(ui.helper[0]).attr("src"), x, y);
			} else if (category === "basic") {
				//console.log($(ui.helper[0]).attr("data-method"));

				window[$(ui.helper[0]).attr("data-method")].call(this, x, y);
				//addTextType(x, y);
			} else if (category === "editable") {
				//console.log("addText");
				addText(x, y);
			} else if(category === "savedItems"){
				addImage($(ui.helper[0]).attr("src"), x, y);
			}
		}
	});
}


function loadImages(tag, imageArray) {
	imageArray.forEach(function (image) {
		var $div = $("<div></div>");
		$div.attr("class", "col-md-6 wb_list_item_container ");
		$div.attr("data-toggle", "tooltip");
		$div.attr("data-placement", "right");
		$div.attr("title", "Drag & drop");

		var $img = $("<img/>");
		$img.attr("src", image.path);
		$img.attr("data-image", image.path);
		$img.attr("data-category", tag);
		if (image.hasOwnProperty("method")) {
			$img.attr("data-method", image.method);
		}
		$img.addClass("wb_list_item draggable");
		$div.append($img);
		$("#" + tag).append($div);
	});

}

function commentBox(threadId){
	var data = {};
	data.threadId = threadId;
	$('#comments-container').comments({
		// enableAttachments: false,
		enableDeleting: false,
		enableNavigation: false,
		enableUpvoting: false,
		enableEditing: true,
		createdByCurrentUser : false,
	    profilePictureURL: 'images/user-icon.png',
	    getComments: function(success, error) {
	    	data.action = "getAllComments";
	    	$.ajax({
	            type: 'get',
	            url: '/Whiteboard/action',
	            data: data,
	            success: function(comment) {
	            	console.log(comment);
	            	comment = JSON.parse(comment);
	                success(comment.comments);
	            },
	            error: error
	        });

	    },
	    postComment: function(commentJSON, success, error) {
	    	console.log(commentJSON);
	    	data.action = "addNewComment";
	    	commentJSON.fullname =  sessionStorage.getItem("username");
	    	commentJSON.created_by_current_user = false;
	    	data.commentjson = JSON.stringify(commentJSON);
	       $.ajax({
	            type: 'post',
	            url: '/Whiteboard/action',
	            data: data,
	            success: function(comment) {
	            	comment = JSON.parse(comment);
	            	success(comment);   
	            },
	            error: error
	        });
	    },

	});
}

/*
document.getElementById('add_image').onchange = function handleImage(e) {
    var reader = new FileReader();
    reader.onload = function (event) { 
    	console.log('Image upload');
        var imgObj = new Image();
        imgObj.src = event.target.result;
        imgObj.onload = function () {
            // start fabricJS stuff
            
            var image = new fabric.Image(imgObj);
            image.set({
                left: 250,
                top: 250,
                angle: 20,
                padding: 10,
                cornersize: 10
            });
            //image.scale(getRandomNum(0.1, 0.25)).setCoords();
            canvas.add(image);
            
            // end fabricJS stuff
        }
        
    }
    reader.readAsDataURL(e.target.files[0]);
}
*/
