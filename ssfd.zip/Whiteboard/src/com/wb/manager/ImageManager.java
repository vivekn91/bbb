package com.wb.manager;


import org.bson.Document;
import org.bson.types.ObjectId;

public class ImageManager {
	private static String collection = "image";
	MongoDbManager dbManager = new MongoDbManager();
	
	
	public String addImage(String imageStr){
		String id = null;
		Document doc = new Document();	
		try{
			
			doc.append("image", imageStr);
			id = dbManager.insertOneDocument(collection, doc.toJson());
		} catch(Exception e){
			
		}
		return id;
	}
	
	
	public String getImage(String imageId){
		
		String response = null;
		try {
			Document document = new Document();
			document.append("_id", new ObjectId(imageId));
			
			document = dbManager.getOneDocument(collection, document);
			
			response = document.getString("image");
			
			

		} catch (Exception ex) {
			
		}
		
		return response;
	}
}
