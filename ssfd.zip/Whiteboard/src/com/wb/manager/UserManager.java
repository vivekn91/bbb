package com.wb.manager;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.bson.Document;

import com.wb.bean.UserDetails;
import com.wb.dao.UserDetailsDAO;

public class UserManager {

	private static String collection = "user";
	MongoDbManager dbManager = new MongoDbManager();
	
	/*ROLE*/
	/*
	 * TM  TEAM MEMBER
	 * TL  TEAM LEAD
	 */
	
	/**
	 * 
	 * @param userDetails
	 * @return
	 */
	public String saveUser(UserDetails userDetails){
		
		Document doc = new Document();
		doc.append("userid", userDetails.getUserid().trim());
		doc.append("userName", userDetails.getUserName().trim());
		doc.append("ctsUserId", userDetails.getCtsUserId().trim());
		doc.append("email", userDetails.getEmail().trim());
		doc.append("fullName", userDetails.getFullName().trim());
		doc.append("role", "TM");
		
		String id = dbManager.insertOneDocument(collection, doc.toJson());
		
		doc.append("objectId", id);
		return doc.toJson();
	}
	
	public boolean updateUser(String userId, String updateJSONData){
		boolean flag = false;
		//TODO generate query json
		Document doc = new Document();
		doc.append("userid", userId);
		
		flag =  dbManager.updateDocument(collection, doc, updateJSONData);
		
		return flag;
	}
	
	public boolean deleteUser(String userId){
		boolean flag = false;
		Document doc = new Document();
		doc.append("_id", userId);
		flag = dbManager.deleteOneDocument(collection, doc.toJson());
		return flag;
	}
	
	public String getUser(String userNamePassword){
		String projectsJson=null;
		Document doc = new Document();
		doc = Document.parse(userNamePassword);
		UserDetails details = new UserDetails();
		
		details.setUserid("cts\\"+doc.getString("username").trim());

		
		details.setPassword(doc.getString("password").trim());
		details.setCtsUserId(doc.getString("username").trim());
		
		//System.out.println(doc.toJson());
		
		details = UserDetailsDAO.getUserDetailsDB(details);
		
		if (details.isUserValid()) {
			Document checkUserId =  new Document();
			
			checkUserId.append("userid", new Document().append("$eq", details.getUserid().trim()));

			//System.out.println(checkUserId.toJson());
			doc = dbManager.getOneDocument(collection, checkUserId);
			//System.out.println("doc"+doc);
			if (doc == null) {
				projectsJson = this.saveUser(details);
			} else {
				details.setUserid(doc.getString("username"));
				projectsJson = doc.toJson();
			}
		}
		
		return projectsJson;
	}
	
	public String getUserRole(String userId){
		String role = null;
		try{
			Document doc = new Document();
			doc.append("userid", userId);
			doc = dbManager.getOneDocument(collection, doc);
			//System.out.println(doc);
			role = doc.getString("role");
		}catch(Exception e){
			Logger.getLogger("com.manager").log(Level.SEVERE, e.getMessage(), e);
		}
		return role;
	}
	
	public static void main(String args[]){
		UserManager manager = new UserManager();
		
		Document document = new Document();
		document.append("role", "TL");
		Document updateJson = new Document();
		updateJson.append("$set", document);
		String updateData = updateJson.toJson();
		String userid ="419895";
		
		manager.updateUser(userid, updateData);
		
	}
	
}
