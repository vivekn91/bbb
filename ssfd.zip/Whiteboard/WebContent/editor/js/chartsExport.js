




var wbC3Chart = {
	c3line: function (dom) {
		c3.generate({
			bindto: dom,
			data: {
				columns: [
            ['data1', 30, 200, 100, 400, 150, 250],
            ['data2', 50, 20, 10, 40, 15, 25]
        ]
			}
		});
	},
	c3pie: function (dom) {
		c3.generate({
			bindto: dom,
			data: {
				// iris data from R
				columns: [
            ['data1', 30],
            ['data2', 120],
        ],
				type: 'pie'
			}
		});
	},
	c3multiline: function (dom) {
		c3.generate({
			bindto: dom,
			data: {
				xs: {
					'data1': 'x1',
					'data2': 'x2',
				},
				columns: [
            ['x1', 10, 30, 45, 50, 70, 100],
            ['x2', 30, 50, 75, 100, 120],
            ['data1', 30, 200, 100, 400, 150, 250],
            ['data2', 20, 180, 240, 100, 190]
        ]
			}
		})
	},
	c3step: function (dom) {

		c3.generate({
			bindto: dom,
			data: {
				columns: [
            ['data1', 300, 350, 300, 0, 0, 100],
            ['data2', 130, 100, 140, 200, 150, 50]
        ],
				types: {
					data1: 'step',
					data2: 'area-step'
				}
			}
		});
	},
	c3area: function (dom) {
		c3.generate({
			bindto: dom,
			data: {
				columns: [
            ['data1', 300, 350, 300, 0, 0, 0],
            ['data2', 130, 100, 140, 200, 150, 50]
        ],
				types: {
					data1: 'area',
					data2: 'area-spline'
				}
			}
		});
	},
	c3bar: function (dom) {
		c3.generate({
			bindto: dom,
			data: {
				columns: [
            ['data1', 30, 200, 100, 400, 150, 250],
            ['data2', 130, 100, 140, 200, 150, 50]
        ],
				type: 'bar'
			},
			bar: {
				width: {
					ratio: 0.5 // this makes bar width 50% of length between ticks
				}
				// or
				//width: 100 // this makes bar width 100px
			}
		});
	},
	c3donut: function (dom) {
		c3.generate({
			bindto: dom,
			data: {
				columns: [
            ['data1', 30],
            ['data2', 120],
        ],
				type: 'donut',
			},
			donut: {
				//title: "Iris Petal Width"
			}
		});
	},
	c3gauge: function (dom) {
		c3.generate({
			bindto: dom,
			data: {
				columns: [
            ['data', 91.4]
        ],
				type: 'gauge',
			},
		});
	}
}


$(document).ready(function () {

	$.each($(".wb-chart-lib"),function( i, val ) {
		var domObj = val;
		console.log($(domObj));
		eval("wbC3Chart.c3"+$(domObj).data("chart")+"(domObj)");
	});


});
