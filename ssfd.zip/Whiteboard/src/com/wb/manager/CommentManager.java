package com.wb.manager;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;

public class CommentManager {
	private static String collection = "comment";
	MongoDbManager dbManager = new MongoDbManager();
	
	
	public String addThread(){
		Document doc = new Document();	
		try{
			
			List<Document> list = new ArrayList<>(); 
			doc.append("comments", list);
			String id = dbManager.insertOneDocument(collection, doc.toJson());
			doc.append("objectId", id);
		} catch(Exception e){
			
		}
		return doc.toJson();
	}
	
	public String  addNewComment(String commentThreadId , String commentjson){
		
		String comment = null;
		try {
			boolean flag = false;
			// id for the comment thread
			Document id = new Document();
			id.append("_id", new ObjectId(commentThreadId));

			// user comment
			Document doc = Document.parse(commentjson);
			doc.append("id", new ObjectId().toHexString());

			Document commentArrayObj = new Document();
			commentArrayObj.append("comments", doc);

			Document push = new Document();
			push.append("$push", commentArrayObj);

			flag = dbManager.updateDocument(collection, id, push.toJson());
			if(flag){
				comment = doc.toJson();
			}

		} catch (Exception ex) {
			
		}
		
		return comment;
	}
	

	public String getComments(String commentThreadId){
		
		String response = null;
		try {
			Document document = new Document();
			document.append("_id", new ObjectId(commentThreadId));
			
			document = dbManager.getOneDocument(collection, document);
			
			response = document.toJson();

		} catch (Exception ex) {
			
		}
		
		return response;
	}
	
}
