package com.wb.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;

import com.wb.manager.CommentManager;
import com.wb.manager.ImageManager;
import com.wb.manager.ProjectManager;

/**
 * Servlet implementation class action
 */
@WebServlet("/action")
public class action extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public action() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String act = request.getParameter("action");
		//PrintWriter out = response.getWriter();
		
		ProjectManager manager = new ProjectManager();
		CommentManager commentManager = new CommentManager();
		
		try {
			if("getAllProjects".equals(act)){
				String username = request.getParameter("username");
				String userid = request.getParameter("userid");
				response.getWriter().print(manager.getProjects(username, userid));
			}else if("getAllComments".equals(act)){
				String commentThreadId = request.getParameter("threadId");
				response.getWriter().print(commentManager.getComments(commentThreadId));
			}else if ("getImage".equals(act)){
				ImageManager imgMgr =new ImageManager();
				String getObjectId = request.getParameter("id");
				String imageStr = imgMgr.getImage(getObjectId);
				byte[] imageBytes = Base64.decodeBase64(imageStr.split(",")[1]);
				String contentType = imageStr.split(";")[0];
				response.setContentType(contentType.split(":")[1]);
				response.getOutputStream().write(imageBytes);
			} else if("getProjectCount".equals(act)){
				String username = request.getParameter("username");
				response.getWriter().print(manager.getProjectCountUserBased(username));
			}
		} catch (Exception e) {
			Logger.getLogger("com.wb.servlet").log(Level.SEVERE, e.getMessage(), e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String act = request.getParameter("action");
		PrintWriter out = response.getWriter();
		
		ProjectManager projectManager = new ProjectManager();
		CommentManager commentManager = new CommentManager();
		
		try {
			if ("addProject".equals(act)) {
				String project = request.getParameter("project");
				/*String type = request.getParameter("type");
				String commentId = request.getParameter("commentId");
				String projectName = request.getParameter("projectName");
				String preview = request.getParameter("preview");
				out.print(projectManager.saveProject(project, type, commentId, projectName,preview));*/
				out.print(projectManager.saveProject(project));
			} else if ("editProject".equals(act)) {
				String project = request.getParameter("project");
				/*String objectId = request.getParameter("objectId");
				String preview = request.getParameter("preview");
				out.print(projectManager.updateProject(project, objectId, preview));*/
				out.print(projectManager.updateProject(project));
			}  else if ("addThread".equals(act)){
				out.print(commentManager.addThread());
			} else if ("addNewComment".equals(act)){
				String commentThreadId = request.getParameter("threadId");
				String commentjson = request.getParameter("commentjson");
				out.print(commentManager.addNewComment(commentThreadId, commentjson));
			} else if ("addImage".equals(act)){
				ImageManager imgMgr =new ImageManager();
				String imagebase64 = request.getParameter("imagebase64");
				out.print(imgMgr.addImage(imagebase64));
			} 
		} catch (Exception e) {
			Logger.getLogger("com.wb.servlet").log(Level.SEVERE, e.getMessage(), e);
		}
		
	}

}
