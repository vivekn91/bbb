package com.wb.dao;

import java.util.logging.Logger;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;


import com.wb.bean.UserDetails;
import com.wb.manager.LDAPDataAccessManager;

public class UserDetailsDAO {

	static Logger log = Logger.getLogger(UserDetailsDAO.class.getName());

	private static LDAPDataAccessManager ldapInstance = null;
	private static final String EMAIL_FIELD = "mail";
	private static final String USERNAME_FIELD = "userPrincipalName";
	private static final String USERID_FIELD = "samaccountname";
	private static final String DISPLAYNAME_FIELD = "givenName";
	private static final String FULLNAME_FIELD = "cn";
	private static final String FIELD_SPILTER = ":";
	private static DirContext context = null;

	/* method to retrieve login details from LDAP */
	public static UserDetails getUserDetailsDB(UserDetails details) {

		details = LDAPDataAccessManager.editUserDetails(details);

		NamingEnumeration<SearchResult> results = null;

		String searchstring = "(&(objectclass=user)(sAMAccountName="
				+ details.getUserid() + "))";

		try {

			ldapInstance = LDAPDataAccessManager.getInstance(details);
			//log.info("Inside method getUserDetailsDB");

			context = ldapInstance.getContext();

			SearchControls controls = new SearchControls();
			controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			results = context.search("", searchstring, controls);
			SearchResult searchResult = (SearchResult) results.next();
			Attributes attributes = searchResult.getAttributes();
			
			String email = attributes.get(EMAIL_FIELD).toString()
					.split(FIELD_SPILTER)[1];
			String username = attributes.get(USERNAME_FIELD).toString()
					.split(FIELD_SPILTER)[1];
			String userId = attributes.get(USERID_FIELD).toString()
					.split(FIELD_SPILTER)[1];
			String fullName = attributes.get(FULLNAME_FIELD).toString()
					.split(FIELD_SPILTER)[1];
			String displayName = attributes.get(DISPLAYNAME_FIELD).toString()
					.split(FIELD_SPILTER)[1];

			details.setPasswordValid(true);
			details.setUserName(displayName);
			details.setUserValid(true);
			details.setUserid(userId);
			details.setDisplayName(username);
			details.setEmail(email);
			details.setFullName(fullName);
		}

		catch (NamingException exception) {
			//exception.printStackTrace();
			details.setPasswordValid(false);
			details.setUserValid(false);
		}
		catch (NullPointerException exception) {
			//exception.printStackTrace();
			details.setPasswordValid(false);
			details.setUserValid(false);
		}


		finally {
			ldapInstance.closeContext();
		}
		//System.out.println(details.isUserValid());
		return details;
	}
	
	public static void main(String args[]){
		UserDetails details=new UserDetails();
		details.setCtsUserId("526101");
		details.setUserid("cts\\526101");
		
		details = getUserDetailsDB(details);
		
		System.out.println(details.getEmail());
		
	}
}